package app.tjhome;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * One row of video cards above the app grid: a small heading, a status note, and a horizontally
 * scrolling strip of thumbnails. Plain views only (no RecyclerView, no animation): a shelf holds
 * at most a dozen cards, so there is nothing to recycle and nothing to animate.
 *
 * The cards are built once and then re-pointed at new videos in place (see show), so a refresh that
 * rotates the recommendations costs a few setText / setImageBitmap calls instead of inflating and
 * measuring a whole new strip on the UI thread.
 */
final class Shelf extends LinearLayout {

    interface OnOpen { void open(String videoId); }

    /** What a card currently shows; lives in the card's tag. */
    private static final class Card {
        String id, meta;
        Bitmap bmp;
        ImageView img;
        TextView badge, title;
    }

    private final float density;
    private final int imgW, imgH;
    private final TextView note;
    private final HorizontalScrollView scroller;
    private final LinearLayout row;
    private OnOpen open;
    private String lastNote = "";

    // one listener for every card: it reads the video id the card shows right now
    private final OnClickListener click = new OnClickListener() {
        @Override public void onClick(View v) {
            Object tag = v.getTag();
            if (open != null && tag instanceof Card) open.open(((Card) tag).id);
        }
    };

    Shelf(Context ctx, String name, float density, float scale) {
        super(ctx);
        this.density = density;
        imgW = dp(160 * scale);      // 25% bigger than the old 128 x 72
        imgH = dp(90 * scale);
        setOrientation(VERTICAL);

        LinearLayout head = new LinearLayout(ctx);
        head.setOrientation(HORIZONTAL);
        head.setGravity(Gravity.BOTTOM);
        head.setPadding(dp(6), 0, 0, dp(1));

        TextView title = new TextView(ctx);
        title.setText(name);
        title.setTextColor(0xFFF2B84B);          // same amber as the clock and the focus ring
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        head.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        note = new TextView(ctx);
        note.setTextColor(0x99FFFFFF);
        note.setTextSize(13);
        note.setSingleLine(true);
        note.setEllipsize(TextUtils.TruncateAt.END);
        note.setPadding(dp(10), 0, 0, 0);
        head.addView(note, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addView(head, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        row = new LinearLayout(ctx);
        row.setOrientation(HORIZONTAL);

        scroller = new HorizontalScrollView(ctx);
        scroller.setFocusable(false);            // the cards take focus, never the strip itself
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setOverScrollMode(OVER_SCROLL_NEVER);
        scroller.addView(row, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        scroller.setVisibility(GONE);
        addView(scroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private int dp(float v) { return (int) (v * density + 0.5f); }

    /** Width in pixels at which a card shows its picture (all shelves use the same size). */
    int imageWidth() { return imgW; }

    /** Ignores a note that is already showing: TextView.setText always costs a relayout. */
    void setNote(String s) {
        if (s.equals(lastNote)) return;
        lastNote = s;
        note.setText(s);
    }

    /** Drops every card (and so every bitmap). Used when the system asks for memory back. */
    void clear() {
        row.removeAllViews();
        scroller.setVisibility(GONE);
    }

    /**
     * Shows these videos. Existing cards are re-pointed at the new videos in place and only what
     * really changed is touched (an unchanged card costs nothing); cards are added or removed only
     * when the number of videos changed.
     */
    void show(List<Feed.Item> items, Bitmap[] thumbs, String[] meta, OnOpen open) {
        this.open = open;
        boolean hadFocus = hasFocus();
        int n = items.size();
        boolean other = false;   // true when some slot now holds a different video

        while (row.getChildCount() > n) row.removeViewAt(row.getChildCount() - 1);
        for (int i = 0; i < n; i++) {
            if (i < row.getChildCount()) {
                other |= bind((Card) row.getChildAt(i).getTag(), items.get(i), thumbs[i], meta[i]);
            } else {
                row.addView(card(items.get(i), thumbs[i], meta[i]));
                other = true;
            }
        }
        scroller.setVisibility(n == 0 ? GONE : VISIBLE);
        if (other && !hadFocus) scroller.scrollTo(0, 0);   // new videos: start at the first card again
    }

    /** Re-points one card at a video; returns true when the card now holds a different video. */
    private boolean bind(Card c, Feed.Item it, Bitmap bmp, String meta) {
        boolean other = !it.id.equals(c.id);
        if (other) {
            c.id = it.id;
            c.title.setText(it.title);
            c.bmp = bmp;
            c.img.setImageBitmap(bmp);
        } else if (bmp != null && c.bmp == null) {   // same video, its thumbnail arrived since
            c.bmp = bmp;
            c.img.setImageBitmap(bmp);
        }
        if (!meta.equals(c.meta)) {
            c.meta = meta;
            c.badge.setText(meta);
        }
        return other;
    }

    private View card(Feed.Item it, Bitmap bmp, String meta) {
        Context c = getContext();
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(VERTICAL);
        card.setPadding(dp(6), dp(6), dp(6), dp(6));
        card.setFocusable(true);
        card.setClickable(true);
        card.setBackgroundResource(R.drawable.focus);       // same amber ring as the app tiles
        card.setOnClickListener(click);

        FrameLayout pic = new FrameLayout(c);
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackgroundColor(0x22FFFFFF);
        if (bmp != null) iv.setImageBitmap(bmp);
        pic.addView(iv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView badge = new TextView(c);                    // "TJPW · 2d" on the picture
        badge.setText(meta);
        badge.setTextColor(0xFFFFFFFF);
        badge.setTextSize(12);
        badge.setSingleLine(true);
        badge.setEllipsize(TextUtils.TruncateAt.END);
        badge.setBackgroundColor(0xAA000000);
        badge.setPadding(dp(4), dp(1), dp(4), dp(1));
        pic.addView(badge, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START));
        card.addView(pic, new LinearLayout.LayoutParams(imgW, imgH));

        TextView t = new TextView(c);
        t.setText(it.title);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(14);
        t.setLines(2);                                      // fixed height: every card lines up
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setShadowLayer(3, 0, 1, 0xFF000000);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                imgW, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(3);
        card.addView(t, tp);

        Card h = new Card();
        h.id = it.id;
        h.meta = meta;
        h.bmp = bmp;
        h.img = iv;
        h.badge = badge;
        h.title = t;
        card.setTag(h);
        return card;
    }
}
