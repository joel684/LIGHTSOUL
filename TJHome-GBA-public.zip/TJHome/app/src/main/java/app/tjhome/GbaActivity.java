package app.tjhome;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.nio.charset.StandardCharsets;

/** Full-screen GBA player. EmulatorJS supplies the emulation core; ROMs are selected by the user. */
public final class GbaActivity extends Activity {
    private static final int PICK_ROM = 431;
    /** The one server the player page may load anything from (the EmulatorJS runtime + core). */
    private static final String EJS_HOST = "cdn.emulatorjs.org";
    private static final String TAG = "TJGBA";
    /** The page's own (fake) origin. Only the one ROM path below is ever answered from the app itself. */
    private static final String PAGE_HOST = "gba.tjhome.local";
    private static final String ROM_PATH = "/bundled-rom.gba";
    /** Personal builds only: a ROM placed in src/main/assets/gba/rom/ (git-ignored) ships inside the APK. */
    private static final String ROM_DIR = "gba/rom";
    /** File name of the bundled ROM, or null when this build has none (every public build). */
    private String bundledRom;
    private WebView web;
    private ValueCallback<Uri[]> fileResult;
    private volatile boolean emulatorActive;

    /**
     * Every request the player page makes goes through this check. Only the EmulatorJS CDN (https)
     * and in-page data/blob URLs are allowed; any other server - an analytics ping, an ad, a second
     * CDN - is refused before it leaves the TV. The emulator's "is there a newer version" ping is
     * refused too: it only writes a console message and is of no use here.
     */
    static boolean allowedRequest(Uri u) {
        String scheme = u.getScheme();
        if ("data".equals(scheme) || "blob".equals(scheme) || "about".equals(scheme)) return true;
        if (!"https".equals(scheme) || !EJS_HOST.equalsIgnoreCase(u.getHost())) return false;
        String path = u.getPath();
        return path == null || !path.endsWith("/version.json");
    }

    private static WebResourceResponse blockedResponse() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                null, new ByteArrayInputStream(new byte[0]));
    }


    private static boolean isBundledRomRequest(WebResourceRequest r) {
        Uri u = r.getUrl();
        return "GET".equalsIgnoreCase(r.getMethod()) && "https".equals(u.getScheme())
                && PAGE_HOST.equalsIgnoreCase(u.getHost()) && ROM_PATH.equals(u.getPath());
    }

    /** First .gba / .zip in assets/gba/rom, or null. Missing folder (public build) simply means null. */
    private String findBundledRom() {
        try {
            String[] names = getAssets().list(ROM_DIR);
            if (names == null) return null;
            for (String n : names) {
                String l = n.toLowerCase(java.util.Locale.ROOT);
                if (l.endsWith(".gba") || l.endsWith(".zip")) return n;
            }
        } catch (Exception ignored) { }
        return null;
    }

    /**
     * Streams the bundled ROM straight out of the APK to the page: it is never held in the Java heap, and
     * "no-store" keeps the 16 MB out of the WebView's HTTP cache (the page turns it into a blob: URL, which
     * the emulator never caches either - so the emulator cache holds only the core).
     */
    private WebResourceResponse bundledRomResponse() {
        try {
            if (bundledRom == null) throw new java.io.FileNotFoundException("no bundled ROM");
            InputStream in = getAssets().open(ROM_DIR + "/" + bundledRom, AssetManager.ACCESS_STREAMING);
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "no-store");
            return new WebResourceResponse("application/octet-stream", null, 200, "OK", headers, in);
        } catch (Exception e) {
            Log.w(TAG, "bundled ROM could not be opened: " + e);
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found",
                    null, new ByteArrayInputStream(new byte[0]));
        }
    }

    /** Shows a problem on the player screen too (a failed emulator start is otherwise just a black screen). */
    private void diag(final String msg) {
        Log.w(TAG, msg);
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (web != null) web.evaluateJavascript(
                        "window.TJDiag&&window.TJDiag.note(" + JSONObject.quote(msg) + ")", null);
            }
        });
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        bundledRom = findBundledRom();
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enterImmersive();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // nothing here is loaded from file:// or content:// URLs (the page comes from the app's assets
        // as a string; a chosen ROM reaches the page through the file chooser), so both stay off
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setGeolocationEnabled(false);
        if (Build.VERSION.SDK_INT >= 26) {
            settings.setSafeBrowsingEnabled(false);   // Safe Browsing would send URL hashes to Google
        }
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        web.addJavascriptInterface(new RemoteBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (isBundledRomRequest(request)) return bundledRomResponse();
                if (allowedRequest(request.getUrl())) return null;
                Uri u = request.getUrl();
                String path = u.getPath() == null ? "" : u.getPath();
                // the emulator's own version.json ping and the browser's favicon lookup are blocked on
                // purpose and are not problems worth showing
                if (path.endsWith("/version.json") || path.endsWith("/favicon.ico")) Log.d(TAG, "blocked: " + u);
                else diag("Blocked request: " + u.getHost() + path);
                return blockedResponse();
            }

            // A WebView renderer killed by the system (usually: out of memory) leaves a dead black view.
            // Leave the player cleanly instead; returning true also stops Android from killing the process.
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Log.e(TAG, "WebView renderer gone, crashed=" + detail.didCrash());
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(GbaActivity.this,
                                "The GBA player ran out of memory and was closed.", Toast.LENGTH_LONG).show();
                        finish();
                    }
                });
                return true;
            }

            // the page never navigates anywhere: refuse every link / redirect (this older overload is
            // also what the newer one calls by default, so it covers every Android version)
            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    Toast.makeText(GbaActivity.this,
                            "GBA player page could not load. Check the TV's internet connection.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            // adb logcat -s TJGBA shows everything the page and the emulator say
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                String line = m.message() + "  [" + m.sourceId() + ":" + m.lineNumber() + "]";
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    Log.e(TAG, line);
                    diag("Error: " + m.message());
                } else {
                    Log.d(TAG, line);
                }
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileResult != null) fileResult.onReceiveValue(null);
                fileResult = callback;
                // ACTION_OPEN_DOCUMENT first; some TV boxes only ship the older GET_CONTENT picker
                String[] actions = {Intent.ACTION_OPEN_DOCUMENT, Intent.ACTION_GET_CONTENT};
                for (String action : actions) {
                    Intent pick = new Intent(action);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("*/*");
                    pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(pick, PICK_ROM);
                        return true;
                    } catch (Exception ignored) { }
                }
                // Cancel the request the documented way: answer the callback with null and return TRUE
                // (returning false after answering it makes the WebView handle the request a second time).
                fileResult = null;
                callback.onReceiveValue(null);
                Toast.makeText(GbaActivity.this,
                        "No file picker is available on this device.", Toast.LENGTH_LONG).show();
                return true;
            }
        });
        setContentView(web);

        try (InputStream in = getAssets().open("gba/index.html")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            String html = new String(out.toByteArray(), StandardCharsets.UTF_8);
            // A stable HTTPS origin gives the web emulator normal storage and blob-URL behaviour.
            web.loadDataWithBaseURL("https://gba.tjhome.local/", html,
                    "text/html", "UTF-8", null);
        } catch (Exception e) {
            web.loadDataWithBaseURL("https://gba.tjhome.local/",
                    "<html><body style='background:#080b16;color:white;font:24px sans-serif'>"
                            + "Could not open the built-in GBA player.</body></html>",
                    "text/html", "UTF-8", null);
        }
    }

    private final class RemoteBridge {
        /** Name of the ROM built into this APK, or "" (public builds have none). */
        @JavascriptInterface
        public String bundledRom() {
            return bundledRom == null ? "" : bundledRom;
        }

        @JavascriptInterface
        public void setEmulatorActive(boolean active) {
            emulatorActive = active;
        }

        /** "Exit" chosen inside the emulator's own menu: leave the player instead of a dead-end screen. */
        @JavascriptInterface
        public void exitPlayer() {
            emulatorActive = false;
            runOnUiThread(new Runnable() {
                @Override public void run() { finish(); }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_ROM) return;
        Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
        if (fileResult != null) {
            fileResult.onReceiveValue(uri == null ? null : new Uri[]{uri});
            fileResult = null;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (!emulatorActive || web == null) return super.dispatchKeyEvent(event);

        final int key = event.getKeyCode();
        final int action = event.getAction();
        // Holding BACK leaves the player; a quick BACK press is the GBA B button.
        if (key == KeyEvent.KEYCODE_BACK && action == KeyEvent.ACTION_DOWN
                && (event.isLongPress() || event.getRepeatCount() > 0)) {
            emulatorActive = false;
            finish();
            return true;
        }

        String[] jsKeys = remoteKeys(key);
        if (jsKeys == null) return super.dispatchKeyEvent(event);
        if (action == KeyEvent.ACTION_DOWN && event.getRepeatCount() > 0) return true;
        if (action != KeyEvent.ACTION_DOWN && action != KeyEvent.ACTION_UP) return true;

        // one remote key can press several GBA buttons at once (8 = A+B): all of them go down together
        // and come up together
        boolean down = action == KeyEvent.ACTION_DOWN;
        StringBuilder js = new StringBuilder("if(window.TJRemote){");
        for (String k : jsKeys) {
            js.append("window.TJRemote.key(").append(JSONObject.quote(k)).append(",")
              .append(down ? "true" : "false").append(");");
        }
        js.append("}");
        web.evaluateJavascript(js.toString(), null);
        return true;
    }

    private static final String A = "z", B = "x", L = "q", R = "w";   // the emulator's keyboard keys

    private String[] remoteKeys(int code) {
        switch (code) {
            // number keys on the TV remote
            case KeyEvent.KEYCODE_1: case KeyEvent.KEYCODE_NUMPAD_1: return new String[]{L};
            case KeyEvent.KEYCODE_3: case KeyEvent.KEYCODE_NUMPAD_3: return new String[]{R};
            case KeyEvent.KEYCODE_7: case KeyEvent.KEYCODE_NUMPAD_7: return new String[]{A};
            case KeyEvent.KEYCODE_9: case KeyEvent.KEYCODE_NUMPAD_9: return new String[]{B};
            case KeyEvent.KEYCODE_8: case KeyEvent.KEYCODE_NUMPAD_8: return new String[]{A, B};   // A+B together
            case KeyEvent.KEYCODE_5: case KeyEvent.KEYCODE_NUMPAD_5: return new String[]{"v"};    // SELECT
            default: break;
        }
        String one = remoteKey(code);
        return one == null ? null : new String[]{one};
    }

    private String remoteKey(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP: return "ArrowUp";
            case KeyEvent.KEYCODE_DPAD_DOWN: return "ArrowDown";
            case KeyEvent.KEYCODE_DPAD_LEFT: return "ArrowLeft";
            case KeyEvent.KEYCODE_DPAD_RIGHT: return "ArrowRight";
            case KeyEvent.KEYCODE_BUTTON_A: return "z";       // GBA A (gamepads; on the remote A is the 7 key)
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_BUTTON_B: return "x";        // GBA B
            case KeyEvent.KEYCODE_BUTTON_X: return "a";        // GBA X (where supported)
            case KeyEvent.KEYCODE_BUTTON_Y: return "s";        // GBA Y (where supported)
            case KeyEvent.KEYCODE_BUTTON_SELECT:
            case KeyEvent.KEYCODE_MEDIA_REWIND: return "v";   // SELECT
            case KeyEvent.KEYCODE_DPAD_CENTER:                // the remote's OK key
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: return "Enter"; // START
            case KeyEvent.KEYCODE_BUTTON_L1:
            case KeyEvent.KEYCODE_PAGE_UP: return "q";        // L
            case KeyEvent.KEYCODE_BUTTON_R1:
            case KeyEvent.KEYCODE_PAGE_DOWN: return "w";      // R
            default: return null;
        }
    }

    private void enterImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersive();
    }

    // The emulator must not keep running (CPU, memory, sound) while another screen is in front.
    @Override
    protected void onPause() {
        if (web != null) {
            web.onPause();
            web.pauseTimers();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.resumeTimers();
            web.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        emulatorActive = false;
        if (fileResult != null) {
            fileResult.onReceiveValue(null);
            fileResult = null;
        }
        if (web != null) {
            web.stopLoading();
            web.loadUrl("about:blank");
            web.removeJavascriptInterface("AndroidBridge");
            // WebView.destroy() is only valid once the view is out of the view tree; destroying it while
            // still attached keeps the WebView (and this activity) alive and logs a warning
            if (web.getParent() instanceof ViewGroup) ((ViewGroup) web.getParent()).removeView(web);
            web.removeAllViews();
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
