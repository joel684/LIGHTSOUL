package app.tjhome;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * Keeps the launcher's own cache folder (the "Cache" figure Android shows under App info) under a
 * fixed size. Plain Java on purpose (no Android classes), so it can be tested on a desktop JVM.
 *
 * What is in that folder: the video thumbnails (about 10 KB each) and, for a little while, the
 * downloaded APK of a pending self-update. Nothing else is ever written there.
 *
 * Over the cap, the OLDEST files go first - except
 *   - the files in `keep` (the thumbnails of the videos on the shelves right now: deleting those
 *     would only make the next pass download them again), and
 *   - a downloaded update (update-*.apk) that is waiting to be installed.
 * Half-finished downloads (*.tmp, *.part) that nobody has written to for ten minutes are always
 * deleted.
 */
final class CacheCleaner {

    /** The most the cache folder may hold: 3 MB. */
    static final long CAP_BYTES = 3L * 1024 * 1024;

    private static final long STALE_TEMP_MS = 10L * 60 * 1000;
    private static final int MAX_FILES = 4000;   // far more than ever exist; a guard against a runaway folder
    private static final int MAX_DEPTH = 3;

    private static final class Entry {
        final File file;
        final long len, modified;

        Entry(File f) {
            file = f;
            len = f.length();
            modified = f.lastModified();
        }
    }

    /**
     * Brings the folder under {@code cap} bytes.
     *
     * @param root the cache folder (subfolders are included)
     * @param keep names of files that are never deleted
     * @param now  System.currentTimeMillis()
     * @return the number of bytes freed
     */
    static long trim(File root, Set<String> keep, long cap, long now) {
        List<Entry> all = new ArrayList<>();
        collect(root, all, 0);

        long total = 0, freed = 0;
        List<Entry> removable = new ArrayList<>();
        for (Entry e : all) {
            String n = e.file.getName();
            boolean temp = n.endsWith(".tmp") || n.endsWith(".part");
            if (temp && now - e.modified > STALE_TEMP_MS) {   // left behind by an interrupted download
                if (e.file.delete()) freed += e.len;
                continue;
            }
            total += e.len;
            boolean pendingUpdate = n.startsWith("update-") && n.endsWith(".apk");
            if (!pendingUpdate && !keep.contains(n)) removable.add(e);
        }
        if (total <= cap) return freed;

        Collections.sort(removable, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) {
                int c = Long.compare(a.modified, b.modified);   // oldest first
                return c != 0 ? c : a.file.getName().compareTo(b.file.getName());
            }
        });
        for (Entry e : removable) {
            if (total <= cap) break;
            if (e.file.delete()) {
                total -= e.len;
                freed += e.len;
            }
        }
        return freed;
    }

    private static void collect(File dir, List<Entry> out, int depth) {
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            if (out.size() >= MAX_FILES) return;
            if (f.isDirectory()) {
                if (depth < MAX_DEPTH) collect(f, out, depth + 1);
            } else {
                out.add(new Entry(f));
            }
        }
    }

    private CacheCleaner() { }
}
