package app.tjhome;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.ArrayList;

/**
 * The column of shelves above the app grid.
 *
 * Three shelves one above the other would squeeze the app grid to less than one row on a 1080p TV,
 * so the panel is only as tall as TWO shelves (ONE on a screen too short for two, see setKeepBelow)
 * plus the heading of the next one peeking in at the bottom. Moving the cursor down onto a shelf that
 * is out of view scrolls it into view (a ScrollView scrolls to whatever child takes focus, nothing
 * else to wire up), and moving back up scrolls it away again. With no more shelves than fit, nothing
 * scrolls at all.
 *
 * No scroll bar, no over-scroll glow, no smooth-scroll animation: same "nothing animates" rule as
 * the rest of the launcher.
 */
final class ShelfPanel extends ScrollView {

    private static final int FULL = 2;   // most shelves that are shown in full; any further shelf peeks in

    private final LinearLayout column;
    private final int headRoom;          // px: a focused card also reveals this much above itself (its shelf heading)
    private final int slack;             // px: tolerance when judging whether a card is fully on screen
    private int keepBelow;               // px: height that must stay free under the panel (the app grid's minimum)
    private int tallest;                 // px: tallest shelf seen so far, so an empty shelf does not shrink the panel

    ShelfPanel(Context ctx, float density) {
        super(ctx);
        headRoom = (int) (34 * density + 0.5f);   // 6 dp gap + the 16 sp heading of a shelf, with a little spare
        slack = (int) (2 * density + 0.5f);
        column = new LinearLayout(ctx);
        column.setOrientation(LinearLayout.VERTICAL);
        super.addView(column, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setFocusable(false);                       // the cards take focus, never the panel itself
        setVerticalScrollBarEnabled(false);
        setOverScrollMode(OVER_SCROLL_NEVER);
        setFadingEdgeLength(0);
        setSmoothScrollingEnabled(false);
    }

    /**
     * The panel sits above the app grid, so it has to leave the grid this much height (px) below it.
     * When two shelves would not leave that much, the panel shows one shelf in full instead.
     */
    void setKeepBelow(int px) {
        keepBelow = px;
    }

    void addShelf(Shelf shelf, int topMarginPx) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = topMarginPx;
        column.addView(shelf, lp);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        super.onMeasure(widthSpec, heightSpec);   // as tall as all the shelves, up to what the parent allows
        int n = column.getChildCount();
        for (int i = 0; i < n; i++) {
            View c = column.getChildAt(i);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) c.getLayoutParams();
            tallest = Math.max(tallest, c.getMeasuredHeight() + lp.topMargin + lp.bottomMargin);
        }

        int full = FULL;
        if (MeasureSpec.getMode(heightSpec) != MeasureSpec.UNSPECIFIED) {
            int room = MeasureSpec.getSize(heightSpec) - keepBelow;   // what the panel may use and still leave the apps their room
            while (full > 1 && tallest * full + headRoom > room) full--;
        }
        if (n <= full) return;
        int cap = tallest * full + headRoom;
        if (cap < getMeasuredHeight()) setMeasuredDimension(getMeasuredWidth(), cap);
    }

    /** A card that takes focus brings its shelf heading into view with it (the first shelf then rests at the very top). */
    @Override
    protected int computeScrollDeltaToGetChildRectOnScreen(Rect rect) {
        Rect want = new Rect(rect);               // the caller's rect stays untouched
        want.top = Math.max(0, want.top - headRoom);
        return super.computeScrollDeltaToGetChildRectOnScreen(want);
    }

    /**
     * The shelves sit above the app grid, so a card that is scrolled out of view lies (on screen)
     * over the grid, and "up" from an app would pick it as the nearest card. So while the cursor is
     * outside the panel only the cards that are fully in view can be reached; once it is inside,
     * every card can be (that is how the panel scrolls to the next shelf).
     */
    @Override
    public void addFocusables(ArrayList<View> views, int direction, int focusableMode) {
        if (hasFocus()) {
            super.addFocusables(views, direction, focusableMode);
            return;
        }
        ArrayList<View> all = new ArrayList<>();
        super.addFocusables(all, direction, focusableMode);
        Rect r = new Rect();
        for (View v : all) {
            r.set(0, 0, v.getWidth(), v.getHeight());
            offsetDescendantRectToMyCoords(v, r);   // the panel's content coordinates...
            r.offset(-getScrollX(), -getScrollY()); // ...moved to what is on screen right now
            if (r.top >= -slack && r.bottom <= getHeight() + slack
                    && r.right > 0 && r.left < getWidth()) {
                views.add(v);
            }
        }
    }
}
