package app.tjhome;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Everything about the online shelves that is not UI: download the channel feeds, read them,
 * keep a small text cache on disk, and choose what to show. Plain Java on purpose (no Android
 * classes), so it stays tiny and can be tested on a desktop JVM.
 *
 * Careful with API levels: this app supports Android 5.0 (API 21), so no List.sort,
 * Collection.removeIf, Map.getOrDefault, Comparator.comparing... (all API 24+).
 */
final class Feed {

    static final class Item {
        final String id;      // YouTube video id
        final String src;     // Sources.Src.label
        final long pub;       // upload time, ms since epoch (0 if unknown)
        final String title;

        Item(String id, String src, long pub, String title) {
            this.id = id;
            this.src = src;
            this.pub = pub;
            this.title = title;
        }
    }

    static final class Cache {
        long fetched;                       // last time at least one feed was downloaded
        final List<Item> items = new ArrayList<>();
    }

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final String UA = "Mozilla/5.0 (Linux; Android TV) TJHome";

    static final int MAX_WRESTLING = 12;
    static final int MAX_MOVIES = 10;
    static final int MAX_KDRAMA = 10;
    private static final int MIN_WRESTLING = 6;   // pad with newest uploads if too few full shows
    private static final int PER_SOURCE = 3;      // so one channel cannot fill the whole shelf
    private static final int PER_SOURCE_KDRAMA = 4;   // fewer channels feed this shelf, so each may fill a little more

    private static final Comparator<Item> NEWEST = new Comparator<Item>() {
        @Override public int compare(Item a, Item b) { return Long.compare(b.pub, a.pub); }
    };
    private static final Comparator<Item> BY_ID = new Comparator<Item>() {
        @Override public int compare(Item a, Item b) { return a.id.compareTo(b.id); }
    };

    // ------------------------------------------------------------------ choosing what to show

    /**
     * @param seed decides the "recommendations" mix of all three shelves (wrestling, movies, K-drama).
     *             Pass the time of the last successful download (Cache.fetched): the picks then change exactly when the feeds
     *             are refreshed (every REFRESH_MS in MainActivity, 10 minutes) and stay put in between,
     *             e.g. when coming back from an app or while offline.
     */
    static List<Item> pick(List<Item> all, int group, long seed) {
        List<Item> good = new ArrayList<>(), rest = new ArrayList<>();
        for (Item i : all) {
            Sources.Src s = Sources.byLabel(i.src);
            if (s == null || s.group != group) continue;
            if (s.blocked(i.title)) continue;   // fan meetings, talks...: not even as filler below
            if (s.accepts(i.title)) good.add(i); else rest.add(i);
        }

        // "recommendations": a mix across channels, reshuffled with every refresh. The list is put in a
        // fixed order first, so the same seed always gives the same shelf.
        Collections.sort(good, BY_ID);
        Collections.shuffle(good, new Random(seed));

        if (group == Sources.MOVIES || group == Sources.KDRAMA) {
            return group == Sources.KDRAMA
                    ? take(good, PER_SOURCE_KDRAMA, MAX_KDRAMA)
                    : take(good, PER_SOURCE, MAX_MOVIES);
        }

        // wrestling: shuffled like the others (any recent full show of any promotion can come up, at most
        // PER_SOURCE from one promotion); the age on each card still tells how old it is
        List<Item> out = take(good, PER_SOURCE, MAX_WRESTLING);
        if (out.size() < MIN_WRESTLING) {
            // channels with no recognisable "full show" title still get their newest upload shown
            Collections.sort(rest, NEWEST);
            HashMap<String, Integer> have = new HashMap<>();
            for (Item i : out) have.put(i.src, 1);
            for (Item i : rest) {
                if (out.size() >= MIN_WRESTLING) break;
                if (have.containsKey(i.src)) continue;
                have.put(i.src, 1);
                out.add(i);
            }
        }
        Collections.shuffle(out, new Random(seed + 1));   // so the padding above is not always last
        return out;
    }

    private static List<Item> take(List<Item> in, int perSource, int max) {
        HashMap<String, Integer> n = new HashMap<>();
        List<Item> out = new ArrayList<>();
        for (Item i : in) {
            if (out.size() >= max) break;
            Integer c = n.get(i.src);
            int cnt = c == null ? 0 : c;
            if (cnt >= perSource) continue;
            n.put(i.src, cnt + 1);
            out.add(i);
        }
        return out;
    }

    /** "5m", "3h", "2d", "4w", "3mo" - how old an upload is. */
    static String age(long pub, long now) {
        if (pub <= 0) return "";
        long s = Math.max(0, (now - pub) / 1000);
        if (s < 3600) return Math.max(1, s / 60) + "m";
        if (s < 86400) return (s / 3600) + "h";
        if (s < 14 * 86400L) return (s / 86400) + "d";
        if (s < 70 * 86400L) return (s / (7 * 86400L)) + "w";
        return (s / (30 * 86400L)) + "mo";
    }

    // ------------------------------------------------------------------ downloading

    /**
     * Downloads every channel feed that is due and merges it into the cache. A channel that fails
     * keeps its old items. Gives up early when the first two requests both fail (no real internet).
     * Returns how many channels were refreshed.
     */
    static int refresh(Cache c) {
        int ok = 0, failed = 0;
        for (Sources.Src s : Sources.ALL) {
            byte[] raw = http(s.feedUrl(), 400 * 1024, 8000, 10000);
            List<Item> got = raw == null ? null : parse(new String(raw, UTF8), s.label);
            if (got == null || got.isEmpty()) {
                if (ok == 0 && ++failed >= 2) break;
                continue;
            }
            for (int k = c.items.size() - 1; k >= 0; k--) {
                if (c.items.get(k).src.equals(s.label)) c.items.remove(k);
            }
            c.items.addAll(got);
            ok++;
        }
        if (ok > 0) c.fetched = System.currentTimeMillis();
        return ok;
    }

    // ------------------------------------------------------------------ network allow-list

    /**
     * The ONLY servers this app's own code ever talks to: YouTube's public channel feeds and
     * thumbnails, and GitHub (release check + the APK download, which GitHub serves from a
     * *.githubusercontent.com host). Anything else - including a redirect to some other host - is
     * refused, and plain http is never used. Nothing else is sent anywhere: no account, no device
     * id, no analytics; the only request header is a generic User-Agent.
     */
    private static boolean allowedHost(URL u) {
        if (!"https".equals(u.getProtocol())) return false;
        String h = u.getHost();
        if (h == null) return false;
        h = h.toLowerCase(Locale.US);
        return h.equals("www.youtube.com") || h.equals("i.ytimg.com")
                || h.equals("api.github.com") || h.equals("github.com")
                || h.endsWith(".githubusercontent.com");
    }

    /**
     * Opens url and returns the connection of the final answer, or null when the address (or any
     * redirect on the way) is not allowed. Redirects are followed by hand, up to 5, so that every
     * hop is checked against allowedHost.
     */
    private static HttpURLConnection open(String url, int connectMs, int readMs) throws IOException {
        URL u = new URL(url);
        for (int hop = 0; hop < 6; hop++) {
            if (!allowedHost(u)) return null;
            HttpURLConnection h = (HttpURLConnection) u.openConnection();
            try {
                h.setInstanceFollowRedirects(false);
                h.setConnectTimeout(connectMs);
                h.setReadTimeout(readMs);
                h.setRequestProperty("User-Agent", UA);
                int code = h.getResponseCode();
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    String loc = h.getHeaderField("Location");
                    h.disconnect();
                    if (loc == null) return null;
                    u = new URL(u, loc);
                    continue;
                }
                return h;
            } catch (IOException | RuntimeException e) {
                h.disconnect();
                throw e;
            }
        }
        return null;
    }

    static byte[] http(String url, int maxBytes, int connectMs, int readMs) {
        HttpURLConnection h = null;
        InputStream in = null;
        try {
            h = open(url, connectMs, readMs);
            if (h == null || h.getResponseCode() != 200) return null;
            in = h.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream(32 * 1024);
            byte[] buf = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > maxBytes) return null;
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } catch (Throwable t) {
            return null;
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) { }
            if (h != null) h.disconnect();
        }
    }

    /**
     * Streams a download straight into a file (never more than maxBytes), so a bigger file - the
     * app's own update - does not have to fit in memory first. False, and no file left behind, on
     * any problem.
     */
    static boolean download(String url, File dest, int maxBytes, int connectMs, int readMs) {
        HttpURLConnection h = null;
        InputStream in = null;
        FileOutputStream out = null;
        boolean ok = false;
        try {
            h = open(url, connectMs, readMs);
            if (h == null || h.getResponseCode() != 200) return false;
            int expected = h.getContentLength();                 // -1 when the server does not say
            if (expected > maxBytes) return false;               // too big: do not even start
            in = h.getInputStream();
            out = new FileOutputStream(dest);
            byte[] buf = new byte[16 * 1024];
            int n, total = 0;
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > maxBytes) return false;
                out.write(buf, 0, n);
            }
            if (expected >= 0 && total != expected) return false;   // the connection was cut: do not keep half a file
            ok = true;
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) { }
            if (out != null) try { out.close(); } catch (Exception ignored) { }
            if (h != null) h.disconnect();
            if (!ok) dest.delete();
        }
    }

    /** Downloads one thumbnail (320x180 JPEG, ~10 KB) to dest. */
    static boolean thumb(String videoId, File dest) {
        byte[] b = http("https://i.ytimg.com/vi/" + videoId + "/mqdefault.jpg", 300 * 1024, 6000, 8000);
        if (b == null || b.length < 200) return false;
        File tmp = new File(dest.getPath() + ".tmp");
        try {
            FileOutputStream o = new FileOutputStream(tmp);
            try { o.write(b); } finally { o.close(); }
            return tmp.renameTo(dest);
        } catch (Throwable t) {
            tmp.delete();
            return false;
        }
    }

    // ------------------------------------------------------------------ parsing (YouTube Atom)

    /**
     * Pulls the uploads out of a channel feed. The feed is machine generated and very regular, so
     * a small scanner is enough (and cheaper than a full XML parser on a weak TV chip).
     * YouTube Shorts are skipped.
     */
    static List<Item> parse(String xml, String srcLabel) {
        List<Item> out = new ArrayList<>();
        int pos = 0;
        while (out.size() < 30) {
            int s = entryStart(xml, pos);
            if (s < 0) break;
            int e = xml.indexOf("</entry>", s);
            if (e < 0) break;
            pos = e + 8;
            String block = xml.substring(s, e);

            String id = text(block, "yt:videoId");
            String title = text(block, "title");
            if (id == null || title == null || !validId(id)) continue;
            String link = linkHref(block);
            if (link != null && link.contains("/shorts/")) continue;

            long pub = parseTime(text(block, "published"));
            out.add(new Item(id, srcLabel, pub, title.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim()));
        }
        return out;
    }

    /** A YouTube video id is exactly 11 chars of [A-Za-z0-9_-]; it also becomes a file name. */
    static boolean validId(String id) {
        if (id.length() != 11) return false;
        for (int i = 0; i < 11; i++) {
            char c = id.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
                    || c == '_' || c == '-';
            if (!ok) return false;
        }
        return true;
    }

    private static int entryStart(String xml, int from) {
        int i = from;
        while (true) {
            i = xml.indexOf("<entry", i);
            if (i < 0) return -1;
            char c = i + 6 < xml.length() ? xml.charAt(i + 6) : '>';
            if (c == '>' || c == ' ' || c == '\n' || c == '\r' || c == '\t') return i;
            i += 6;
        }
    }

    /** Text of the first <name>...</name> in s (entities decoded), or null. */
    private static String text(String s, String name) {
        int a = s.indexOf("<" + name + ">");
        if (a < 0) return null;
        a += name.length() + 2;
        int b = s.indexOf("</" + name + ">", a);
        if (b < 0) return null;
        return unescape(s.substring(a, b));
    }

    /** href of the first <link rel="alternate" .../> (the watch / shorts url). */
    private static String linkHref(String s) {
        int i = 0;
        while ((i = s.indexOf("<link", i)) >= 0) {
            int end = s.indexOf('>', i);
            if (end < 0) return null;
            String tag = s.substring(i, end);
            if (tag.contains("alternate")) {
                int h = tag.indexOf("href=\"");
                if (h >= 0) {
                    h += 6;
                    int q = tag.indexOf('"', h);
                    if (q > h) return unescape(tag.substring(h, q));
                }
            }
            i = end;
        }
        return null;
    }

    static String unescape(String s) {
        if (s.indexOf('&') < 0) return s;
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '&') { b.append(c); continue; }
            int semi = s.indexOf(';', i);
            if (semi < 0 || semi - i > 10) { b.append(c); continue; }
            String e = s.substring(i + 1, semi);
            String rep = null;
            if (e.equals("amp")) rep = "&";
            else if (e.equals("lt")) rep = "<";
            else if (e.equals("gt")) rep = ">";
            else if (e.equals("quot")) rep = "\"";
            else if (e.equals("apos")) rep = "'";
            else if (e.startsWith("#")) {
                try {
                    int cp = e.startsWith("#x") || e.startsWith("#X")
                            ? Integer.parseInt(e.substring(2), 16) : Integer.parseInt(e.substring(1));
                    rep = new String(Character.toChars(cp));
                } catch (Exception ignored) { }
            }
            if (rep == null) { b.append(c); continue; }
            b.append(rep);
            i = semi;
        }
        return b.toString();
    }

    /** "2026-10-18T09:30:00+00:00" -> epoch ms (0 when unreadable). No SimpleDateFormat: it is slow and zone-sensitive. */
    static long parseTime(String s) {
        if (s == null || s.length() < 19) return 0;
        try {
            long y = Long.parseLong(s.substring(0, 4)), mo = Long.parseLong(s.substring(5, 7)),
                    d = Long.parseLong(s.substring(8, 10)), h = Long.parseLong(s.substring(11, 13)),
                    mi = Long.parseLong(s.substring(14, 16)), sec = Long.parseLong(s.substring(17, 19));
            long t = ((daysFromCivil(y, mo, d) * 24 + h) * 60 + mi) * 60 + sec;
            int i = 19;
            if (i < s.length() && s.charAt(i) == '.') {
                i++;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            }
            if (i + 5 < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) {
                long off = (Long.parseLong(s.substring(i + 1, i + 3)) * 60
                        + Long.parseLong(s.substring(i + 4, i + 6))) * 60;
                t += s.charAt(i) == '+' ? -off : off;
            }
            return t * 1000;
        } catch (Exception e) {
            return 0;
        }
    }

    private static long daysFromCivil(long y, long m, long d) {   // proleptic Gregorian, days since 1970-01-01
        y -= m <= 2 ? 1 : 0;
        long era = (y >= 0 ? y : y - 399) / 400;
        long yoe = y - era * 400;
        long doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
        long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
        return era * 146097 + doe - 719468;
    }

    // ------------------------------------------------------------------ disk cache (tab separated)

    static Cache load(File f) {
        Cache c = new Cache();
        BufferedReader r = null;
        try {
            r = new BufferedReader(new InputStreamReader(new FileInputStream(f), UTF8));
            String head = r.readLine();
            // v3: more channels arrived. An older cache has no items from them, so it is ignored once
            // and every feed is downloaded straight away instead of after the next refresh.
            // (v2: the K-drama shelf arrived.)
            if (head == null || !head.startsWith("v3\t")) return c;
            c.fetched = Long.parseLong(head.substring(3).trim());
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t", 4);
                if (p.length < 4 || !validId(p[0]) || Sources.byLabel(p[1]) == null) continue;
                long pub;
                try {
                    pub = Long.parseLong(p[2]);
                } catch (NumberFormatException bad) {
                    continue;   // one damaged line must not throw away the rest of the cache
                }
                c.items.add(new Item(p[0], p[1], pub, p[3]));
            }
        } catch (Throwable ignored) {
            // missing or damaged cache just means "nothing cached yet"
        } finally {
            if (r != null) try { r.close(); } catch (Exception ignored) { }
        }
        return c;
    }

    static void save(File f, Cache c) {
        File tmp = new File(f.getPath() + ".tmp");
        try {
            Writer w = new OutputStreamWriter(new FileOutputStream(tmp), UTF8);
            try {
                w.write("v3\t" + c.fetched + "\n");
                for (Item i : c.items) {
                    w.write(i.id + "\t" + i.src + "\t" + i.pub + "\t" + i.title + "\n");
                }
            } finally {
                w.close();
            }
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f); }
        } catch (Throwable t) {
            tmp.delete();
        }
    }

    private Feed() { }
}
