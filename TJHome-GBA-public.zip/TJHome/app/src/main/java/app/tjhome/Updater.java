package app.tjhome;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.app.PendingIntent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Self-update from the GitHub Releases of REPO. The workflow in .github/workflows publishes every
 * push as a release whose tag is "v" + the build's versionCode, so "newer" is a plain number
 * comparison. Android only accepts the new APK if it is signed with the same key as the installed
 * one, so a wrong or tampered file can never replace the launcher.
 *
 * Two steps, so a download never interrupts anything:
 *   fetch()   - background thread, Wi-Fi only (the caller checks): look for a newer release and
 *               download it (~1 MB) into the cache folder.
 *   install() - only called while the home screen is in front: hands the file to the system
 *               installer, which shows one "Install" confirmation (see InstallRx).
 */
final class Updater {

    static final String REPO = "joel684/TJhome";
    static final long CHECK_MS = 2L * 60 * 60 * 1000;        // how often GitHub is checked for a newer release
    static final long PROMPT_MS = 6L * 60 * 60 * 1000;       // a declined install prompt is not shown again for this long
    private static final int MAX_APK = 6 * 1024 * 1024;   // the app is under 2 MB; anything bigger is not ours

    private final Context ctx;
    private volatile File ready;    // a downloaded APK that is newer than the installed one, or null

    Updater(Context c) {
        ctx = c.getApplicationContext();
    }

    boolean ready() {
        File f = ready;
        return f != null && f.exists();
    }

    @SuppressWarnings("deprecation")
    private int installedCode() {
        try {
            return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionCode;
        } catch (Throwable e) {
            return Integer.MAX_VALUE;   // cannot tell: never update
        }
    }

    /** True for a personal build that has a ROM inside it (assets/gba/rom): see fetch(). */
    private boolean hasBundledRom() {
        try {
            String[] f = ctx.getAssets().list("gba/rom");
            return f != null && f.length > 0;
        } catch (Throwable e) {
            return false;
        }
    }

    /** Background thread. True when a newer APK is downloaded and waiting. */
    boolean fetch() {
        try {
            // The published releases never contain a ROM, so installing one over a personal build would
            // silently remove the built-in game. Personal builds are updated by hand.
            if (hasBundledRom()) return false;
            int have = installedCode();
            cleanOld(have);
            if (ready()) return true;

            byte[] json = Feed.http("https://api.github.com/repos/" + REPO + "/releases/latest",
                    256 * 1024, 10000, 15000);
            if (json == null) return false;
            JSONObject rel = new JSONObject(new String(json, "UTF-8"));
            String digits = rel.getString("tag_name").replaceAll("[^0-9]", "");
            if (digits.isEmpty() || digits.length() > 9) return false;
            int code = Integer.parseInt(digits);
            if (code <= have) return false;

            String url = null;
            JSONArray assets = rel.getJSONArray("assets");
            for (int i = 0; i < assets.length() && url == null; i++) {
                JSONObject a = assets.getJSONObject(i);
                if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url");
            }
            // only ever download from this repo's own GitHub release page (Feed.open also refuses any
            // host that is not GitHub, on every redirect)
            if (url == null || !url.startsWith("https://github.com/" + REPO + "/releases/download/")) return false;

            File out = new File(ctx.getCacheDir(), "update-" + code + ".apk");
            if (!out.exists()) {
                // streamed straight to disk: the file never has to fit in memory (on a weak TV a
                // 2 MB download held in a byte array, plus its copies, was the biggest spike of all)
                File part = new File(out.getPath() + ".part");
                if (!Feed.download(url, part, MAX_APK, 10000, 60000) || part.length() < 10000) {
                    part.delete();
                    return false;
                }
                if (!part.renameTo(out)) { part.delete(); return false; }
            }
            ready = out;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Removes the downloaded APKs that are already installed. No network, safe on any thread (it
     * leaves half-finished downloads alone: one may be being written right now; CacheCleaner
     * removes those once they are stale).
     */
    void tidy() {
        int have = installedCode();
        if (have == Integer.MAX_VALUE) return;   // cannot tell what is installed: delete nothing
        File[] files = ctx.getCacheDir().listFiles();
        if (files == null) return;
        for (File f : files) {
            String n = f.getName();
            if (!n.startsWith("update-") || !n.endsWith(".apk")) continue;
            try {
                if (Integer.parseInt(n.substring(7, n.length() - 4)) <= have) f.delete();
            } catch (Throwable ignored) { }
        }
    }

    // removes downloads that are already installed (or half finished)
    private void cleanOld(int have) {
        File[] files = ctx.getCacheDir().listFiles();
        if (files == null) return;
        for (File f : files) {
            String n = f.getName();
            if (!n.startsWith("update-")) continue;
            boolean old = true;
            if (n.endsWith(".apk")) {
                try {
                    old = Integer.parseInt(n.substring(7, n.length() - 4)) <= have;
                } catch (Throwable ignored) { }
            }
            if (old) f.delete();
        }
    }

    /** Background thread. Hands the downloaded APK to the system installer. */
    void install() {
        File f = ready;
        if (f == null || !f.exists()) return;
        try {
            PackageManager pm = ctx.getPackageManager();
            // last sanity check: it must be this app, and newer
            @SuppressWarnings("deprecation")
            PackageInfo pi = pm.getPackageArchiveInfo(f.getPath(), 0);
            if (pi == null || !ctx.getPackageName().equals(pi.packageName)
                    || pi.versionCode <= installedCode()) {
                f.delete();
                ready = null;
                return;
            }

            PackageInstaller installer = pm.getPackageInstaller();
            for (PackageInstaller.SessionInfo si : installer.getAllSessions()) {   // leftovers of an earlier, cancelled try
                if (ctx.getPackageName().equals(si.getAppPackageName())) {
                    try { installer.abandonSession(si.getSessionId()); } catch (Throwable ignored) { }
                }
            }

            PackageInstaller.SessionParams p =
                    new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            p.setAppPackageName(ctx.getPackageName());
            if (Build.VERSION.SDK_INT >= 31) {
                // lets Android 12+ update without a prompt once this app has installed itself once
                p.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
            }
            int id = installer.createSession(p);
            PackageInstaller.Session s = installer.openSession(id);
            boolean committed = false;
            try {
                OutputStream out = s.openWrite("tjhome", 0, f.length());
                InputStream in = new FileInputStream(f);
                try {
                    byte[] buf = new byte[16 * 1024];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    s.fsync(out);
                } finally {
                    in.close();
                    out.close();
                }
                Intent i = new Intent(ctx, InstallRx.class);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT
                        | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
                s.commit(PendingIntent.getBroadcast(ctx, id, i, flags).getIntentSender());
                committed = true;
            } finally {
                s.close();
                // a session that never got committed would keep its copy of the APK on disk until abandoned
                if (!committed) {
                    try { installer.abandonSession(id); } catch (Throwable ignored) { }
                }
            }
        } catch (Throwable ignored) { }
    }
}
