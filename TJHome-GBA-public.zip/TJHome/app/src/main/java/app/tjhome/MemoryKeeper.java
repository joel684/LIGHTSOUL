package app.tjhome;

import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Process;
import android.provider.Settings;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Frees memory by asking the system to stop the background processes of apps nobody is using.
 *
 * What it does NOT do, by design:
 *  - It never clears any app's data. It only calls ActivityManager.killBackgroundProcesses, which
 *    is the same thing the system does itself when it runs low on memory: the app's files, logins
 *    and settings stay exactly as they are, and the app simply starts fresh the next time it opens.
 *  - It never stops the app in use. Layers of protection, from strongest to weakest:
 *      1. The system itself refuses to kill foreground, visible or perceptible processes (the
 *         screen you are looking at, picture-in-picture, anything playing audio through a
 *         foreground service). killBackgroundProcesses only touches processes that are idle.
 *      2. The app that was last opened from this launcher (or from a shelf card) is left alone
 *         for GRACE_MS, so hopping Home and straight back never cold-starts it.
 *      3. If "usage access" was granted to this app (optional, see below), the app that is in
 *         front right now, and every app used in the last GRACE_MS, is left alone as well.
 *
 * Optional extra protection (layer 3), one time, from a computer:
 *     adb shell appops set app.tjhome GET_USAGE_STATS allow
 *
 * Only apps that have an icon on the home screen are ever touched, and never the ones in KEEP.
 */
final class MemoryKeeper {

    /** How often a sweep runs. */
    static final long SWEEP_MS = 5L * 60 * 1000;
    /** An app used this recently is left alone. */
    static final long GRACE_MS = 5L * 60 * 1000;
    /** How far back the usage log is read to find the app in front. */
    private static final long USAGE_WINDOW_MS = 12L * 60 * 60 * 1000;

    /** Never swept, even though they may show up in the launcher grid. Edit to taste. */
    private static final String[] KEEP = {
            "com.android.vending",                 // Play Store: updates and downloads
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
            "com.google.android.gms",
            "com.google.android.gsf",
            "com.google.android.katniss",          // voice search / assistant
            "com.google.android.tvlauncher",
            "com.google.android.tvrecommendations",
            "com.google.android.leanbacklauncher",
            "com.google.android.tv.remote.service",
            "com.google.android.tv",               // live TV
    };

    private final Context ctx;

    MemoryKeeper(Context c) {
        ctx = c.getApplicationContext();
    }

    /**
     * Runs one sweep. Blocking binder calls: call it from a background thread.
     *
     * @param candidates     packages of the apps on the home screen
     * @param lastLaunched   package last opened from this launcher ("" if none)
     * @param lastLaunchedAt System.currentTimeMillis() of that launch
     */
    void sweep(List<String> candidates, String lastLaunched, long lastLaunchedAt) {
        try {
            long now = System.currentTimeMillis();
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return;

            Set<String> spare = new HashSet<>();
            spare.add(ctx.getPackageName());
            for (String k : KEEP) spare.add(k);
            String ime = inputMethodPackage();
            if (ime != null) spare.add(ime);
            if (lastLaunched != null && now - lastLaunchedAt < GRACE_MS) spare.add(lastLaunched);
            addRecentlyUsed(spare, now);

            PackageManager pm = ctx.getPackageManager();
            for (String pkg : candidates) {
                if (spare.contains(pkg) || isPersistent(pm, pkg)) continue;
                try {
                    am.killBackgroundProcesses(pkg);
                } catch (Throwable ignored) { }   // one stubborn app must not stop the sweep
            }
        } catch (Throwable ignored) { }
    }

    private String inputMethodPackage() {
        try {
            String id = Settings.Secure.getString(ctx.getContentResolver(),
                    Settings.Secure.DEFAULT_INPUT_METHOD);
            ComponentName cn = id == null ? null : ComponentName.unflattenFromString(id);
            return cn == null ? null : cn.getPackageName();
        } catch (Throwable e) {
            return null;
        }
    }

    private static boolean isPersistent(PackageManager pm, String pkg) {
        try {
            return (pm.getApplicationInfo(pkg, 0).flags
                    & android.content.pm.ApplicationInfo.FLAG_PERSISTENT) != 0;
        } catch (Throwable e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ usage access (optional)

    @SuppressWarnings("deprecation")
    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) ctx.getSystemService(Context.APP_OPS_SERVICE);
            if (ops == null) return false;
            int mode = ops.checkOpNoThrow("android:get_usage_stats", Process.myUid(),
                    ctx.getPackageName());
            if (mode == AppOpsManager.MODE_DEFAULT) {
                return ctx.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS")
                        == PackageManager.PERMISSION_GRANTED;
            }
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable e) {
            return false;
        }
    }

    /**
     * Adds the app in front right now, and every app used within GRACE_MS, to {@code spare}.
     * Does nothing when usage access was not granted.
     */
    @SuppressWarnings("deprecation")
    private void addRecentlyUsed(Set<String> spare, long now) {
        if (!hasUsageAccess()) return;
        try {
            UsageStatsManager usm = (UsageStatsManager) ctx.getSystemService("usagestats");
            if (usm == null) return;
            UsageEvents events = usm.queryEvents(now - USAGE_WINDOW_MS, now);
            if (events == null) return;

            Map<String, Long> lastSeen = new HashMap<>();
            String front = null;   // package of the last "came to front" with no "went to back" after it
            UsageEvents.Event e = new UsageEvents.Event();
            while (events.hasNextEvent()) {
                events.getNextEvent(e);
                int t = e.getEventType();
                if (t != UsageEvents.Event.MOVE_TO_FOREGROUND
                        && t != UsageEvents.Event.MOVE_TO_BACKGROUND) continue;
                String p = e.getPackageName();
                if (p == null) continue;
                lastSeen.put(p, e.getTimeStamp());
                if (t == UsageEvents.Event.MOVE_TO_FOREGROUND) front = p;
                else if (p.equals(front)) front = null;
            }
            if (front != null) spare.add(front);
            for (Map.Entry<String, Long> en : lastSeen.entrySet()) {
                if (now - en.getValue() < GRACE_MS) spare.add(en.getKey());
            }
        } catch (Throwable ignored) { }
    }
}
