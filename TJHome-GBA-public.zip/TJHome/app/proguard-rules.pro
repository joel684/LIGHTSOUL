# Release builds are minified (R8). Methods that are only ever called from JavaScript look unused to R8
# and would be removed or renamed, so the GBA player's JavaScript bridge (GbaActivity.RemoteBridge:
# setEmulatorActive, exitPlayer) would silently stop working in the released APK - the TV remote
# would then never be switched over to the game. Keep every @JavascriptInterface method as it is.
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
