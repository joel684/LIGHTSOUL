Smirk GBA player
================

What's new
----------
- A built-in "GBA Games" tile appears in the launcher app grid.
- Selecting it opens the full-screen landscape Game Boy Advance player.
- ROMs are chosen by the user from local storage or an attached USB drive.
- TV remote keys and supported Android gamepad keys are mapped to GBA controls.

TV remote controls
------------------
- Arrow keys: D-pad
- OK / Enter: Start
- 5: Select
- 1: L        3: R
- 7: A        9: B        8: A + B together
- Power, Source, Exit and Home keys are not touched: they keep their normal system functions.
- Short Back press: B (also works as a second B key)
- Hold Back: exit the player
- Also kept: Menu / Play-Pause = Start, Rewind = Select, Page Up / Page Down = L / R.
- Bluetooth gamepad A/B/X/Y/Start/Select/L1/R1 buttons are mapped too.
(All of this lives in GbaActivity.remoteKeys()/remoteKey(); change it there.)

Network and privacy
-------------------
The app has no analytics, ads, crash reporting or other third-party SDKs (zero dependencies), and
nothing is sent to OpenAI or any AI service. The only servers it contacts:
  - www.youtube.com / i.ytimg.com   public channel feeds + thumbnails for the shelves (Wi-Fi/Ethernet only)
  - api.github.com / github.com     update check + APK download from this repo's releases (Wi-Fi/Ethernet only)
  - cdn.emulatorjs.org              only when a game is opened: the emulator runtime and GBA core
Nothing identifying is sent (no account, no device id, no cookies; a generic User-Agent only). The
app's own code refuses any other host (Feed.java), and the GBA player's WebView blocks every request
except to cdn.emulatorjs.org (GbaActivity.java). Plain http is off. Safe Browsing and WebView usage
metrics are switched off for the player. To remove even the EmulatorJS CDN dependency, bundle the
EmulatorJS data/ folder and the GBA core in assets and point EJS_pathtodata at it.

Storage limits
--------------
- Launcher disk cache (thumbnails, update download): 3 MB, trimmed automatically (CacheCleaner).
- Launcher picture caches in RAM: icons 4-8 MB, thumbnails 3-5 MB, scaled to the device's heap.
- GBA player cache (the emulator core, in the WebView): capped at 10 MB (EJS_cacheConfig in
  assets/gba/index.html), old entries removed after 5 days. ROMs from storage are not cached.
  Save states are kept separately.
- The GBA player runs in its own process (android:process=":gba"), so the always-resident launcher
  stays small and the player's memory is released when it is closed.

Personal build with a built-in game
-----------------------------------
Put ONE ROM (.gba or .zip) in app/src/main/assets/gba/rom/ and build. The player's start screen then
shows a "PLAY <game name>" button; with no ROM there (every public build) that button never appears and
nothing else changes. The folder is git-ignored so a ROM cannot be committed by accident. The ROM is streamed out of the APK to the page (never
held in the Java heap, never in any cache) and released as soon as the game has started.
- A build that contains a ROM never self-updates (Updater.hasBundledRom): the published releases have no
  ROM and would remove it. Update personal builds by hand.
- To build a ROM into the GitHub-built APK, remove the .gitignore line and commit the ROM to a PRIVATE
  repository ONLY. The GitHub workflow refuses to build when the repository is
  public and a ROM is in that folder, but that check runs after the push and cannot protect git history:
  before ever making the repo public, delete the ROM AND purge it from history (or publish from a fresh repo).
- Troubleshooting a black screen: the player now prints problems at the bottom of the screen (blocked
  request, script error, no WebGL2) and in logcat:  adb logcat -s TJGBA

ROMs and internet
-----------------
No games or BIOS files are included. Choose a .gba file or a ZIP containing a GBA ROM
that you have the right to use. On first play, an internet connection is required to
load the EmulatorJS runtime/core from https://cdn.emulatorjs.org/stable/data/ . The
launcher and player screen are included locally; the emulation runtime is not bundled.

Emulator attribution
--------------------
The player uses EmulatorJS, an open-source web frontend for RetroArch. EmulatorJS is
licensed under GPL-3.0; upstream project and license:
https://github.com/EmulatorJS/EmulatorJS
https://github.com/EmulatorJS/EmulatorJS/blob/main/LICENSE

The existing project does not include a Gradle wrapper. Open the TJHome folder in
Android Studio (or build with a configured Gradle/Android SDK environment).
