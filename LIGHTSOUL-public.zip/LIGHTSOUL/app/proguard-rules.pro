# Release builds are minified (R8). The launcher has no reflection or JavaScript bridges, so no
# extra keep rules are needed; the default Android rules in app/build.gradle are enough.
