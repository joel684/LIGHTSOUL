package app.lightsoul;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;

/**
 * Receives the installer's answer for a self-update. The only thing to do is to open the system's
 * "Install" confirmation when it asks for one; success and failure need nothing (a successful
 * update simply replaces this app, and the downloaded file is cleaned up on the next check).
 */
public final class InstallRx extends BroadcastReceiver {
    @Override
    @SuppressWarnings("deprecation")
    public void onReceive(Context c, Intent i) {
        int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        if (status != PackageInstaller.STATUS_PENDING_USER_ACTION) return;
        Intent ask = i.getParcelableExtra(Intent.EXTRA_INTENT);
        if (ask == null) return;
        try {
            c.startActivity(ask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Throwable ignored) { }
    }
}
