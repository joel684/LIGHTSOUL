package app.lightsoul;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.SystemClock;

/**
 * Brings the home screen to the front after the TV has booted.
 *
 * Why: many TVs have their own start-up logic that is tied to the TV's stock home app. With another
 * launcher installed they can start on the last HDMI input (or the TV tuner) and leave the launcher
 * waiting behind it. This receiver opens the launcher itself once the TV has booted.
 *
 * What it does, and nothing more:
 *  - acts only when the TV has just BOOTED (not when it wakes from standby, not at any other time);
 *  - two attempts, right away and 12 seconds later (the TV may switch to its input a few seconds after
 *    boot); the second does nothing if the launcher is already in front;
 *  - does nothing when another launcher has been chosen as the home app.
 *
 * Android 10 and newer do not let an app open a screen from the background unless it may "display
 * over other apps". The home screen asks for that once (MainActivity.askOverlayPermission opens the
 * TV's own settings screen for it). Some TVs have no such screen; then it is granted once from a computer:
 *     adb shell appops set app.lightsoul SYSTEM_ALERT_WINDOW allow
 * Without it the attempts are simply refused by the system (older Android needs nothing).
 */
public final class BootRx extends BroadcastReceiver {

    private static final String QUICKBOOT = "android.intent.action.QUICKBOOT_POWERON";   // TV boxes with a fast-boot mode
    private static final long AGAIN_MS = 12L * 1000;

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        if (a == null) return;
        boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(a) || QUICKBOOT.equals(a);
        if (!boot) return;                          // this receiver is exported: ignore anything else
        if (!mayTakeOver(c)) return;
        goHome(c);
        scheduleAgain(c);
    }

    /** True unless a different launcher has been chosen as the home app. */
    static boolean mayTakeOver(Context c) {
        try {
            ResolveInfo ri = c.getPackageManager().resolveActivity(
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                    PackageManager.MATCH_DEFAULT_ONLY);
            if (ri == null || ri.activityInfo == null) return true;
            String p = ri.activityInfo.packageName;
            return p.equals(c.getPackageName()) || p.equals("android");   // "android" = no home app chosen yet (the system's chooser)
        } catch (Throwable e) {
            return true;
        }
    }

    static void goHome(Context c) {
        if (MainActivity.visible) return;           // already in front
        try {
            c.startActivity(new Intent(c, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));
        } catch (Throwable ignored) {
            // refused by the system (see the note above) or no screen yet: nothing else to do
        }
    }

    private static void scheduleAgain(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            int flags = PendingIntent.FLAG_UPDATE_CURRENT
                    | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            PendingIntent pi = PendingIntent.getBroadcast(c, 0,
                    new Intent(c, BootAgainRx.class), flags);   // its own receiver, not exported: other apps cannot trigger it
            am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + AGAIN_MS, pi);
        } catch (Throwable ignored) { }
    }
}
