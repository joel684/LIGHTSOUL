package app.lightsoul;

import java.util.regex.Pattern;

/**
 * What the home screen follows. Edit this file to add / remove channels, then rebuild.
 *
 * Every channel is read through its public YouTube RSS feed (no API key, ~20 KB per channel).
 * To add a channel you need its id (starts with "UC", 24 characters): open the channel on
 * YouTube, then About > Share channel > Copy channel ID.
 * A playlist works the same way: give its id (starts with "PL") instead of a channel id.
 */
final class Sources {

    static final int WRESTLING = 0;   // shelf 1: full shows / full matches (shuffled with every refresh)
    static final int MOVIES = 1;      // shelf 2: international movie picks (full-length, free, licensed channels)

    private static final int CI = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;

    // ---- wrestling: a title must look like a whole show/match, and must not look like a clip ----
    private static final Pattern FULL_SHOW = Pattern.compile(
            "full|episode|\\bep\\.? ?\\d|\\blive\\b|\\bshow\\b|\\bevent\\b|archive|uncut|complete"
                    + "|全試合|全編|フル|生配信|配信|ライブ|大会|アーカイブ|ノーカット|完全版|興行", CI);
    private static final Pattern WRESTLING_CLIP = Pattern.compile(
            "digest|highlight|trailer|teaser|promo|preview|interview|\\bcomments?\\b"
                    + "|press conference|ダイジェスト|ハイライト|予告|会見|コメント|煽り|インタビュー|告知", CI);

    // ---- wrestling: not a match or a show at all (fan events, talks, announcements, behind the
    // scenes, merch, recruiting...). These are NEVER shown - not even as the filler for a channel
    // that has no recognisable full show. To hide one more kind of video, add its word here. ----
    private static final Pattern WRESTLING_NOT_A_SHOW = Pattern.compile(
            // English
            "fan ?meet|meet ?(?:&|and|n) ?greet|autograph|hand ?shake|talk ?(?:show|event)|\\bq ?& ?a\\b"
                    + "|behind the scenes|\\bvlog\\b|\\bmerch(?:andise)?\\b|ticket info|tickets? on sale|\\baudition|recruit"
                    + "|announcement|\\bpodcast|\\bradio\\b|press conference"
                    // Japanese: fan events (fan meeting, handshake, autograph, cheki, photo session...)
                    + "|ファン\\s*ミ|ファン感|ファンクラブ|握手|サイン会|チェキ|撮影会|特典会|交流会|懇親会"
                    + "|お見送り|ハイタッチ"
                    // talks, radio, press conferences, announcements, draws
                    + "|トーク|対談|座談会|ラジオ|ポッドキャスト|会見|お知らせ|発表|調印式|抽選会"
                    // behind the scenes, practice
                    + "|舞台裏|裏側|密着|ドキュメンタリー|メイキング|オフショット|楽屋|公開練習|練習風景"
                    // merch, tickets, recruiting
                    + "|物販|グッズ|チケット情報|チケット発売|チケット販売|チケット先行|先行発売|一般発売"
                    + "|募集|オーディション|入団|入門", CI);

    // ---- movies: skip trailers, songs, scenes and other clips ----
    private static final String CLIP_WORDS =
            "trailer|teaser|promo|\\bsongs?\\b|jukebox|lyrical|\\bscenes?\\b|\\bclips?\\b|compilation"
                    + "|glimpse|\\breview\\b|making of|interview|\\bbts\\b|reaction|mashup|best of|\\btop \\d+"
                    + "|first look|motion poster|\\bshorts?\\b|\\bbgm\\b|sneak peek|coming soon"
                    + "|release date|premiere on|\\bupdate\\b|announcement";
    private static final Pattern MOVIE_CLIP = Pattern.compile(CLIP_WORDS, CI);
    // channels that also post lots of non-movies (clips, episodes) must say "movie" / "film" in the title
    private static final Pattern MOVIE_WORDS = Pattern.compile(
            "full\\s*(?:movie|film)|\\bmovie\\b|\\bfilm\\b|pel[ií]cula|\\bfilme\\b", CI);

    static final class Src {
        final String label;       // shown on the card
        final String channelId;   // YouTube channel id (UC...) or playlist id (PL...)
        final int group;
        private final Pattern must;   // title must match this (null = anything that is not a clip)

        Src(String label, String channelId, int group, Pattern must) {
            this.label = label;
            this.channelId = channelId;
            this.group = group;
            this.must = must;
        }

        String feedUrl() {
            // channel ids start with "UC", playlist ids with "PL"
            String key = channelId.startsWith("PL") ? "playlist_id=" : "channel_id=";
            return "https://www.youtube.com/feeds/videos.xml?" + key + channelId;
        }

        /** Is this a kind of video that is never wanted (a fan meeting, a talk...)? Wrestling only. */
        boolean blocked(String title) {
            return group == WRESTLING && WRESTLING_NOT_A_SHOW.matcher(title).find();
        }

        /** Does this title belong on the shelf (a full show / a real movie, not a clip)? */
        boolean accepts(String title) {
            if (group == WRESTLING) {
                return !WRESTLING_CLIP.matcher(title).find() && FULL_SHOW.matcher(title).find();
            }
            if (MOVIE_CLIP.matcher(title).find()) return false;
            return must == null || must.matcher(title).find();
        }
    }

    static final Src[] ALL = {
            // --- wrestling ---
            new Src("FMW-E", "UCo41MmUgUEvGQbYZWxgMi7w", WRESTLING, null),  // Onita's FMW-E
            new Src("TJPW", "UCQPAIKyGyLCBnbvdwG0j6BQ", WRESTLING, null),   // Tokyo Joshi Pro
            new Src("NOAH", "UC0kNS_0C-3-Yle7KgG7b1Yg", WRESTLING, null),   // NOAH (English channel)
            new Src("DDT", "UC6oCIQ4TRcIWgljXqlDFUyA", WRESTLING, null),
            new Src("JTO", "UCxmS3iGDD3BrLGK7E8M6jxw", WRESTLING, null),    // Just Tap Out
            new Src("M-PRO", "UCEb5EUbFP3HwShlu3dO4c7Q", WRESTLING, null),  // Marvelous
            new Src("GLEAT", "UC2PAyViYA-fin48Swq_QWig", WRESTLING, null),
            new Src("STARDOM", "UCIRohOzkvDyspUb08yG085g", WRESTLING, null),  // STARDOM OFFICIAL (women's, free full shows)
            new Src("WCW", "UCbGG2hv4cWmIrBAIhGiCdSg", WRESTLING, null),      // WWE's WCW archive: full Nitro / Thunder / PPVs
            new Src("TNA", "UCOp8wkVqdrWbFYHjDv946QQ", WRESTLING, null),      // TNA Wrestling (iMPACT! full events)
            // --- international movies: full-length films on official / licensed YouTube channels ---
            // Channel ids below were checked against the channels' own YouTube pages (April 2026 listings).
            // Korean Film Archive: ~200 restored classic Korean films, English subtitles available. Titles look
            // like "[4K] The Hut (1980)" with no "full movie" in them, so no keyword is needed (clips are still dropped).
            new Src("Korean Classics", "UCvH6u_Qzn5RQdz9W198umDw", MOVIES, null),
            // FilmRise: free ad-supported feature films from a licensed distributor (indie, festival, foreign-language).
            new Src("FilmRise", "UC8IHAQMuiJdY6ALuhG7iU8Q", MOVIES, null),
            new Src("FilmRise Features", "UCtAddMIPhKMbLED3KEQiJGw", MOVIES, null),
            // Movie Central also posts clips and episodes, so a title must say movie / film.
            new Src("Movie Central", "UCGBzBkV-MinlBvHBzZawfLQ", MOVIES, MOVIE_WORDS),
            // More world cinema: add a line per channel (Spanish, French, Japanese, Nigerian, Russian classics...).
            // For a channel whose titles do not say "movie", pass null instead of MOVIE_WORDS.
    };

    static Src byLabel(String label) {
        for (Src s : ALL) if (s.label.equals(label)) return s;
        return null;
    }

    private Sources() { }
}
