package app.lightsoul;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    /** True while the home screen is in front (read by BootRx, which only needs to know that). */
    static volatile boolean visible;

    static final class App {
        String label, pkg;
        ResolveInfo ri;
        Intent intent;
    }

    static final class Tile {
        ImageView img;
        TextView txt;
    }

    // The caches are sized from the app's heap limit: a weak device (small heap) gets smaller caches
    // instead of running out of memory, a normal one (an 80 MB heap or more) gets the full size.
    private static final long HEAP = Runtime.getRuntime().maxMemory();
    private static final int CACHE_BYTES = (int) Math.max(4L << 20, Math.min(8L << 20, HEAP / 10));
    private static final int THUMB_CACHE_BYTES = (int) Math.max(3L << 20, Math.min(5L << 20, HEAP / 16));   // up to ~44 full-size 320x180 RGB_565 thumbnails (the three shelves hold at most 32)
    private static final int THUMB_SRC_W = 320;                      // width of the downloaded thumbnails (see Feed.thumb)
    private static final long WEAK_HEAP = 128L << 20;                // a heap this small or smaller counts as a weak device

    private List<App> apps = new ArrayList<>();
    private GridView grid;
    private Adapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int gen;          // only touched on the UI thread; drops stale reloads
    private float density;
    private boolean held;
    private boolean weak;     // low-RAM device (system flag, or a small heap): the wallpaper is kept in 16-bit colour, half the memory

    // icons are decoded on one low-priority thread so they never steal time from scrolling
    private final ExecutorService io = Executors.newSingleThreadExecutor(r ->
            new Thread(() -> {
                Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                r.run();
            }, "icons"));

    // tiles are stored pre-shrunk to exactly the size they are drawn at, capped by bytes
    private final LruCache<String, BitmapDrawable> cache =
            new LruCache<String, BitmapDrawable>(CACHE_BYTES) {
                @Override protected int sizeOf(String k, BitmapDrawable d) {
                    return d.getBitmap().getByteCount();
                }
            };

    // decoded video thumbnails, kept by video id: when the recommendations rotate only the cards
    // that are really new have to be decoded (the rest come straight from here)
    private final LruCache<String, Bitmap> thumbCache =
            new LruCache<String, Bitmap>(THUMB_CACHE_BYTES) {
                @Override protected int sizeOf(String k, Bitmap b) {
                    return b.getByteCount();
                }
            };

    private final Runnable reload = this::load;

    // ---- self-update from GitHub releases (see Updater). Downloads only on Wi-Fi / Ethernet; the
    // installer is only started while the home screen is in front, so it never covers an app.
    private Updater updater;
    private long lastCheck;                  // UI thread only: SystemClock.elapsedRealtime() of the last attempt
    private long lastPrompt;                 // UI thread only: a declined update is not offered again for PROMPT_MS
    private final Runnable updateTick = new Runnable() {
        @Override public void run() {
            checkUpdate();
            ui.postDelayed(this, Updater.CHECK_MS);
        }
    };
    private final Runnable installTry = this::offerUpdate;

    // ---- start at boot (see BootRx). Android 10+ only lets an app open itself in the background when
    // "Display over other apps" is allowed for it. It is asked for ONCE, while the home screen is in front
    // and the remote is quiet: the TV's own settings screen for it opens. A TV without such a screen just
    // ignores the request (BootRx has the adb command for that case). Nothing is asked below Android 10.
    private final Runnable overlayAsk = this::askOverlayPermission;

    // ---- wallpapers: 1280x720 pictures (the subject on the right, dark on the left under the apps).
    // One bitmap is in memory at a time, and none while the home screen is out of sight.
    private static final int[] WALLPAPERS = {
            R.drawable.wp_hike, R.drawable.wp_moon, R.drawable.wp_road, R.drawable.wp_alley};
    private static final long WALL_MS = 30L * 1000;           // a home screen left on screen changes picture by itself this often
    private static final long WALL_AWAY_MS = WALL_MS;         // coming back after this long = a new picture, as if it had kept rotating
    private int wallIdx = new Random().nextInt(WALLPAPERS.length) - 1;   // UI thread only
    private int wallGen;                     // UI thread only: drops a decode that was overtaken
    private boolean wallShown;               // UI thread only: a wallpaper bitmap is set right now
    private long pausedAt;                   // UI thread only
    private final Runnable wallTick = new Runnable() {
        @Override public void run() {
            nextWallpaper();
            ui.postDelayed(this, WALL_MS);
        }
    };

    // ---- memory saver: every SWEEP_MS idle apps are stopped (never their data) and our own caches are trimmed ----
    private MemoryKeeper keeper;
    private boolean resumed;                 // UI thread only: is the home screen in front right now
    private String lastPkg = "";             // UI thread only: app last opened from here, spared for a while
    private long lastAt;
    private final Runnable sweepTick = new Runnable() {
        @Override public void run() {
            sweep();
            ui.postDelayed(this, MemoryKeeper.SWEEP_MS);   // keeps running while an app is in front
        }
    };

    // ---- online shelves (wrestling, international movies): only ever downloaded on Wi-Fi / Ethernet ----
    // The feed has a 10 minute clock that starts whenever new feeds are downloaded (and re-picks the
    // recommendations). Until it runs out the shelves show exactly the same videos:
    //  - coming back from YouTube (or any app) BEFORE it runs out does nothing at all: no download, and
    //    the cards are not rebuilt either;
    //  - coming back AFTER it ran out refreshes once, and that stays for the next 10 minutes;
    //  - while the home screen stays in front, the refresh happens the moment the clock runs out.
    // Nothing is downloaded while another app is in front. The clock only ever runs from the last
    // download, so it does not restart when the home screen comes back.
    private static final long REFRESH_MS = 10L * 60 * 1000;  // the feed's clock
    private static final long RETRY_MS = 3L * 60 * 1000;     // pause after a failed attempt
    // Also refreshed: an empty cache (nothing to keep), and a TV that was switched on a moment ago
    // connecting to Wi-Fi (so the morning does not start with yesterday's videos) - both still only
    // when the clock has run out.
    private static final long BOOT_MS = 5L * 60 * 1000;
    private static final long IDLE_MS = 1500;                // background refreshes wait until the remote was quiet this long
    // tried in this order, so the video opens straight in a YouTube app instead of a chooser
    private static final String[] YOUTUBE_APPS = {
            "com.google.android.youtube.tv", "com.google.android.youtube",
            "com.liskovsoft.smarttubetv.beta", "com.liskovsoft.smarttubetv"};

    static final class Snapshot {
        List<Feed.Item> w, m;
        Bitmap[] wb, mb;            // null = this shelf shows the same cards already, nothing decoded
        String[] wMeta, mMeta;
        long now, fetched;
        boolean online;
        String wSig, mSig;          // one signature per shelf, so a shelf that did not change is left alone
    }

    private Shelf wrestling, movies;
    private ConnectivityManager.NetworkCallback netCb;
    private File feedFile, thumbDir;
    private boolean busy, again, destroyed, hasData;   // UI thread only
    private boolean wantRefresh;                       // UI thread only: the next pass may download new feeds (it still only does when the clock has run out)
    private boolean fromApp;                           // UI thread only: back from another app and no key pressed yet, so nobody is browsing a shelf
    private long lastFetched;                          // UI thread only: when the feeds were last downloaded (Cache.fetched, ms since epoch)
    private long lastKey;                              // UI thread only: when the remote was last used
    private volatile String shownW = "", shownM = "";  // what each shelf currently shows
    private volatile HashSet<String> pinned = new HashSet<>();      // file names of the thumbnails of the videos on the shelves: the cache cleaner never deletes these
    private long lastAttempt;                          // feed thread only

    // one low-priority thread for all network + disk + decoding work of the shelves
    private final ExecutorService feedIo = Executors.newSingleThreadExecutor(r ->
            new Thread(() -> {
                Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                r.run();
            }, "feed"));

    private final Shelf.OnOpen openVideo = this::playOnYoutube;
    private final Runnable wake = () -> {
        if (justBooted()) wantRefresh = true;   // the TV just connected after being switched on: bring the feeds up to date
        requestWorkWhenIdle();
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            wantRefresh = true;                 // the 10 minute clock ran out: new videos
            requestWorkWhenIdle();              // (the next tick is set when this pass is done, see apply)
        }
    };

    // install/uninstall/update send bursts of broadcasts: wait until they settle, then reload once
    private final BroadcastReceiver pkgRx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            ui.removeCallbacks(reload);
            ui.postDelayed(reload, 700);
        }
    };

    private int dp(int v) { return (int) (v * density + 0.5f); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            weak = HEAP <= WEAK_HEAP || (am != null && am.isLowRamDevice());
        } catch (Throwable e) {
            weak = HEAP <= WEAK_HEAP;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(48), dp(27), dp(48), dp(27));

        // clock (self-updating, nearly free), amber like the cat's fur
        TextClock clock = new TextClock(this);
        clock.setTextColor(0xFFF2B84B);
        clock.setTextSize(30);
        root.addView(clock, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // two shelves above the apps: wrestling full shows and international movies.
        // They stop short of the wallpaper's subject (70% of the screen width) and shrink a little on short screens.
        // The panel is two shelves tall (one on a short screen, so the apps below it always keep room);
        // the other shelves scroll into view (see ShelfPanel).
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float scale = Math.max(0.7f, Math.min(1f, (dm.heightPixels / density) / 720f));
        int shelfW = (int) (dm.widthPixels * 0.70f);
        wrestling = new Shelf(this, "WRESTLING", density, scale);
        movies = new Shelf(this, "INTERNATIONAL MOVIES", density, scale);
        ShelfPanel panel = new ShelfPanel(this, density);
        panel.setKeepBelow(dp(12) + dp(184));   // the grid's top margin + a row and a half of apps (a row is 118 dp + 4 dp spacing)
        panel.addShelf(wrestling, dp(6));
        panel.addShelf(movies, dp(6));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                shelfW, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(4);
        root.addView(panel, pp);

        // app grid under the shelves, on the left (4 columns); the subject of the wallpaper owns the right side
        adapter = new Adapter();
        grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(dp(160));
        grid.setStretchMode(GridView.STRETCH_SPACING_UNIFORM);
        grid.setVerticalSpacing(dp(4));
        grid.setSelector(R.drawable.focus);
        grid.setVerticalScrollBarEnabled(false);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        grid.setFadingEdgeLength(0);
        grid.setCacheColorHint(0);
        grid.setSmoothScrollbarEnabled(false);
        grid.setScrollingCacheEnabled(false);   // no per-row drawing-cache bitmaps while scrolling
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, pos, id) -> {
            App a = apps.get(pos);
            try {
                startActivity(a.intent);
                noteLaunched(a.pkg);
            } catch (Exception ignored) { }
        });
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(640), 0, 1f);
        gp.topMargin = dp(12);
        root.addView(grid, gp);
        feedFile = new File(getFilesDir(), "feed.tsv");
        thumbDir = new File(getCacheDir(), "thumbs");

        setContentView(root);
        grid.requestFocus();

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(pkgRx, f);

        keeper = new MemoryKeeper(this);
        ui.postDelayed(sweepTick, MemoryKeeper.SWEEP_MS);
        updater = new Updater(this);
        ui.postDelayed(updateTick, 90 * 1000);     // let the home screen settle first

        load();
        watchNetwork();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (grid != null) { // Home pressed again: back to the first app
            grid.requestFocus();
            grid.setSelection(0);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        visible = true;
        if (!wallShown || SystemClock.uptimeMillis() - pausedAt >= WALL_AWAY_MS) nextWallpaper();
        ui.removeCallbacks(wallTick);
        ui.postDelayed(wallTick, WALL_MS);
        if (lastCheck != 0 && SystemClock.elapsedRealtime() - lastCheck > Updater.CHECK_MS) checkUpdate();
        ui.removeCallbacks(installTry);
        ui.postDelayed(installTry, 2500);          // a downloaded update is offered once the screen has settled
        ui.removeCallbacks(overlayAsk);
        ui.postDelayed(overlayAsk, 20 * 1000);     // the one-time permission request, once everything has settled
        fromApp = true;                      // until the first key press nobody is browsing, so a shelf under the old focus ring may refresh too
        wantRefresh = true;                  // may download, but work() only does when the 10 minute clock has run out
        requestWork();                       // show what is cached; a feed younger than its clock is left exactly as it is
        scheduleTick();
    }

    @Override
    protected void onPause() {
        resumed = false;
        visible = false;
        pausedAt = SystemClock.uptimeMillis();
        ui.removeCallbacks(installTry);
        ui.removeCallbacks(overlayAsk);
        ui.removeCallbacks(wallTick);
        ui.removeCallbacks(tick);
        super.onPause();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_BACKGROUND || level == TRIM_MEMORY_RUNNING_CRITICAL) {
            cache.evictAll();
            thumbCache.evictAll();
        }
        if (level >= TRIM_MEMORY_BACKGROUND && wrestling != null) {
            // we are in the background and memory is tight: drop the thumbnails, they are
            // reloaded from the disk cache the next time the home screen comes back
            wrestling.clear();
            movies.clear();
            shownW = "?";
            shownM = "?";
        }
        if (level >= TRIM_MEMORY_BACKGROUND && !resumed) dropWallpaper();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        visible = false;
        ui.removeCallbacks(reload);
        ui.removeCallbacks(wake);
        ui.removeCallbacks(tick);
        ui.removeCallbacks(sweepTick);
        ui.removeCallbacks(wallTick);
        ui.removeCallbacks(updateTick);
        ui.removeCallbacks(installTry);
        ui.removeCallbacksAndMessages(null);   // everything else still queued (one-off posts hold this activity until they run)
        try {
            unregisterReceiver(pkgRx);
        } catch (Exception ignored) { }        // if this ever threw, the cleanup below would be skipped
        if (netCb != null) {
            try {
                ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE))
                        .unregisterNetworkCallback(netCb);
            } catch (Exception ignored) { }
        }
        io.shutdownNow();
        feedIo.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() { /* a launcher never exits */ }

    // Hold OK on an app: open its system info page (clear data / uninstall / etc.)
    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            lastKey = SystemClock.uptimeMillis();
            fromApp = false;                 // the remote is in use: from now on a shelf being browsed is left alone
        }
        if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                if (held) return true;
                if (e.isLongPress() && grid.hasFocus()) { // only on the app grid, not on a video card
                    held = true;
                    int pos = grid.getSelectedItemPosition();
                    if (pos >= 0 && pos < apps.size()) {
                        try {
                            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + apps.get(pos).pkg))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        } catch (Exception ignored) { }
                    }
                    return true;
                }
            } else if (e.getAction() == KeyEvent.ACTION_UP && held) {
                held = false;
                return true;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    // ------------------------------------------------------------------------------------------
    // self-update
    // ------------------------------------------------------------------------------------------

    // UI thread. Looks for a newer release (and downloads it) on the feed thread, only on Wi-Fi / Ethernet.
    private void checkUpdate() {
        if (destroyed || updater == null || !onHomeNetwork()) return;
        lastCheck = SystemClock.elapsedRealtime();
        try {
            feedIo.execute(() -> {
                if (updater.fetch()) ui.post(this::offerUpdate);
            });
        } catch (Exception ignored) { }
    }

    // UI thread. Starts the system installer, but only while the home screen is in front and the remote is quiet.
    private void offerUpdate() {
        if (destroyed || !resumed || updater == null || !updater.ready()) return;
        long quiet = SystemClock.uptimeMillis() - lastKey;
        if (quiet < IDLE_MS) {
            ui.removeCallbacks(installTry);
            ui.postDelayed(installTry, IDLE_MS - quiet + 50);
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (lastPrompt != 0 && now - lastPrompt < Updater.PROMPT_MS) return;   // declined recently: do not nag
        lastPrompt = now;
        try {
            io.execute(updater::install);
        } catch (Exception ignored) { }
    }

    // UI thread. Opens the "Display over other apps" screen for this app, once in the app's life.
    private void askOverlayPermission() {
        if (destroyed || !resumed || Build.VERSION.SDK_INT < 29) return;
        if (SystemClock.uptimeMillis() - lastKey < 3000) {       // the remote is in use: not now
            ui.postDelayed(overlayAsk, 3000);
            return;
        }
        try {
            if (Settings.canDrawOverlays(this)) return;          // already allowed
            SharedPreferences sp = getSharedPreferences("tj", MODE_PRIVATE);
            if (sp.getBoolean("overlayAsked", false)) return;    // asked before: never nag
            sp.edit().putBoolean("overlayAsked", true).apply();
            Toast.makeText(this, "Please allow \"Display over other apps\" for LIGHTSOUL, "
                    + "so it can open itself when the TV starts", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (Throwable ignored) { }                          // this TV has no such screen
    }

    // ------------------------------------------------------------------------------------------
    // wallpapers
    // ------------------------------------------------------------------------------------------

    // UI thread. Decodes the next picture off the UI thread, then swaps it in as the window background.
    @SuppressWarnings("deprecation")
    private void nextWallpaper() {
        if (destroyed) return;
        wallIdx = (wallIdx + 1) % WALLPAPERS.length;
        final int res = WALLPAPERS[wallIdx];
        final int my = ++wallGen;
        final boolean small = weak;
        new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);   // never steal time from scrolling
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;     // the pictures are already exactly 1280x720
            if (small) {            // weak device: 1.8 MB instead of 3.7 MB per picture (dithered, so no visible banding)
                o.inPreferredConfig = Bitmap.Config.RGB_565;
                o.inDither = true;
            }
            Bitmap b;
            try {
                b = BitmapFactory.decodeResource(getResources(), res, o);
            } catch (Throwable t) {
                return;             // out of memory: keep what is showing
            }
            if (b == null) return;
            final BitmapDrawable d = new BitmapDrawable(getResources(), b);
            ui.post(() -> {
                // overtaken by a newer pick, or we went out of sight meanwhile: do not keep the bitmap
                if (destroyed || my != wallGen || !resumed) return;
                getWindow().setBackgroundDrawable(d);
                wallShown = true;
            });
        }, "wallpaper").start();
    }

    // UI thread. Frees the wallpaper bitmap; the next time the home screen is shown a picture is decoded again.
    private void dropWallpaper() {
        if (!wallShown) return;
        wallGen++;
        wallShown = false;
        getWindow().setBackgroundDrawable(new ColorDrawable(0xFF000000));
    }

    // ------------------------------------------------------------------------------------------
    // memory saver
    // ------------------------------------------------------------------------------------------

    private void noteLaunched(String pkg) {
        lastPkg = pkg;
        lastAt = System.currentTimeMillis();
    }

    // UI thread. Trims our own caches, then asks the system to stop idle apps. No app data is ever
    // cleared, and neither is our feed.tsv; our own cache folder is only kept under its cap (cleanCache).
    private void sweep() {
        if (destroyed || keeper == null) return;
        trimOwnCaches();
        final List<String> pkgs = new ArrayList<>(apps.size());
        for (App a : apps) pkgs.add(a.pkg);
        final String last = lastPkg;
        final long at = lastAt;
        try {
            io.execute(() -> {
                keeper.sweep(pkgs, last, at);
                cleanCache();            // the cache folder is kept under its cap even when nothing is downloaded
            });
        } catch (Exception ignored) { }
    }

    // In memory only; everything is rebuilt from the disk cache the next time it is needed.
    private void trimOwnCaches() {
        thumbCache.evictAll();           // frees the thumbnails that are not on a card right now
        if (resumed) return;             // on screen: leave icons and cards alone, nothing flickers
        cache.evictAll();
        dropWallpaper();
        // While the feed is younger than its clock the shelves stay exactly as they are, so coming back
        // from YouTube shows the same cards at once instead of rebuilding them. Once the clock has run
        // out they are freed (the home screen refreshes when it returns anyway). The system can still
        // ask for them back at any time (onTrimMemory).
        if (wrestling != null && !feedFresh()) {
            wrestling.clear();
            movies.clear();
            shownW = "?";
            shownM = "?";                // the shelves are shown again when the home screen returns
        }
    }

    // ------------------------------------------------------------------------------------------
    // online shelves
    // ------------------------------------------------------------------------------------------

    /** True only on Wi-Fi or Ethernet: nothing is ever downloaded over any other kind of connection. */
    @SuppressWarnings("deprecation")
    private boolean onHomeNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni == null || !ni.isConnected()) return false;
            int t = ni.getType();
            return t == ConnectivityManager.TYPE_WIFI || t == ConnectivityManager.TYPE_ETHERNET;
        } catch (Throwable e) {
            return false;
        }
    }

    // Right after the TV is switched on the feeds are brought up to date as soon as it connects. Later
    // reconnects only fill in what is missing (an empty shelf, thumbnails): the videos stay as they are.
    private void watchNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) {
                    // called on a system thread; wait a moment so the link is really usable
                    ui.removeCallbacks(wake);
                    ui.postDelayed(wake, 3000);
                }
            };
            cm.registerNetworkCallback(new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), netCb);
        } catch (Throwable e) {
            netCb = null;   // no callback: onResume and the 10 minute timer still do their work
        }
    }

    /** True during the first minutes after the TV was switched on (the clock counts time asleep too). */
    private static boolean justBooted() {
        return SystemClock.elapsedRealtime() < BOOT_MS;
    }

    // UI thread. Sets the timer for the moment the feed's clock runs out: REFRESH_MS after the last
    // download, NOT after the home screen came back. Only while the home screen is in front.
    private void scheduleTick() {
        ui.removeCallbacks(tick);
        if (!resumed || destroyed) return;
        long now = System.currentTimeMillis();
        long wait;
        if (lastFetched <= 0 || lastFetched > now) {
            wait = REFRESH_MS;                         // nothing downloaded yet (or the clock went backwards): look again later
        } else {
            wait = lastFetched + REFRESH_MS - now;
            if (wait <= 0) wait = RETRY_MS;            // already due, so the last attempt failed: try again soon
        }
        ui.postDelayed(tick, wait + 2000);             // + 2 s so the clock has certainly run out when the timer fires
    }

    // True while the feed is still younger than its clock (UI thread).
    private boolean feedFresh() {
        long now = System.currentTimeMillis();
        return lastFetched > 0 && lastFetched <= now && now - lastFetched < REFRESH_MS;
    }

    // UI thread. Background refreshes (the timer, the network coming back) wait until the remote has
    // been quiet for a moment, so a refresh never starts in the middle of D-pad scrolling.
    private void requestWorkWhenIdle() {
        if (destroyed) return;
        long quiet = SystemClock.uptimeMillis() - lastKey;
        if (quiet < IDLE_MS) {
            ui.removeCallbacks(wake);
            ui.postDelayed(wake, IDLE_MS - quiet + 50);
        } else {
            requestWork();
        }
    }

    // UI thread. Runs one pass of work() at a time; a request that arrives meanwhile runs right after.
    private void requestWork() {
        if (destroyed) return;
        if (busy) { again = true; return; }
        busy = true;
        if (!hasData && onHomeNetwork()) {
            wrestling.setNote("loading...");
            movies.setNote("loading...");
        }
        final boolean refresh = wantRefresh;   // taken now; a request that arrives while this pass runs stays set for the next one
        wantRefresh = false;
        try {
            feedIo.execute(() -> work(refresh));
        } catch (Exception e) {
            busy = false;
            wantRefresh |= refresh;
        }
    }

    // feed thread: read the cache, download new feeds only if asked to (or nothing is cached) and on Wi-Fi and due,
    // fetch missing thumbnails, decode
    private void work(boolean refresh) {
        Snapshot s = null;
        try {
            long now = System.currentTimeMillis();
            Feed.Cache c = Feed.load(feedFile);
            boolean online = onHomeNetwork();
            // The feed's 10 minute clock: new feeds only once it has run out (or the TV's clock went backwards).
            boolean due = c.fetched > now || now - c.fetched >= REFRESH_MS;
            // The videos only change when asked to (the home screen coming back, or the timer: see
            // onResume and tick) AND the clock has run out. An empty cache has nothing to keep, so it
            // is filled right away.
            boolean mayDownload = refresh || c.items.isEmpty();
            if (online && mayDownload && due && now - lastAttempt > RETRY_MS) {
                lastAttempt = now;
                if (Feed.refresh(c) > 0) Feed.save(feedFile, c);
            }

            s = new Snapshot();
            s.now = now;
            s.fetched = c.fetched;
            s.online = online;
            // seeded with the time of the last download: the recommendations are re-picked with
            // every refresh and stay put in between (coming back from an app, offline...)
            s.w = Feed.pick(c.items, Sources.WRESTLING, c.fetched);
            s.m = Feed.pick(c.items, Sources.MOVIES, c.fetched);
            s.wMeta = meta(s.w, true, now);
            s.mMeta = meta(s.m, false, now);

            HashSet<String> pin = new HashSet<>();
            for (Feed.Item it : s.w) pin.add(it.id + ".jpg");
            for (Feed.Item it : s.m) pin.add(it.id + ".jpg");
            pinned = pin;

            thumbDir.mkdirs();
            if (online) fetchThumbs(s.w, s.m);
            pruneThumbs(c.items);
            if (online) cleanCache();   // new thumbnails may have been downloaded: stay under the cap

            s.wSig = signature(s.w, s.wMeta);
            s.mSig = signature(s.m, s.mMeta);
            if (!s.wSig.equals(shownW)) s.wb = decode(s.w);   // only decode a shelf whose cards really changed
            if (!s.mSig.equals(shownM)) s.mb = decode(s.m);
        } catch (Throwable t) {
            s = null;
        }
        final Snapshot out = s;
        ui.post(() -> apply(out));
    }

    private String[] meta(List<Feed.Item> items, boolean withAge, long now) {
        String[] out = new String[items.size()];
        for (int i = 0; i < out.length; i++) {
            Feed.Item it = items.get(i);
            String age = withAge ? Feed.age(it.pub, now) : "";
            out[i] = age.isEmpty() ? it.src : it.src + " · " + age;
        }
        return out;
    }

    private File thumbFile(Feed.Item it) { return new File(thumbDir, it.id + ".jpg"); }

    private String signature(List<Feed.Item> items, String[] meta) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            b.append(items.get(i).id).append(thumbFile(items.get(i)).exists() ? '+' : '-').append(meta[i]).append(';');
        }
        return b.toString();
    }

    // downloads the thumbnails we do not have yet; two failures in a row = no real internet, stop
    private void fetchThumbs(List<Feed.Item> a, List<Feed.Item> b) {
        List<Feed.Item> all = new ArrayList<>(a);
        all.addAll(b);
        int failed = 0;
        for (Feed.Item it : all) {
            File f = thumbFile(it);
            if (f.exists()) continue;
            if (Feed.thumb(it.id, f)) failed = 0;
            else if (++failed >= 2) return;
        }
    }

    // RGB_565: half the memory of the default, and thumbnails do not need alpha.
    // Already decoded thumbnails come from thumbCache, so only new cards cost any decoding time.
    private Bitmap[] decode(List<Feed.Item> items) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.RGB_565;
        // A card shows the thumbnail only imageWidth() pixels wide. When that is half the downloaded
        // width or less (a 720p TV), decode it at half size: a quarter of the memory and decode time,
        // and the same picture on screen.
        int want = wrestling.imageWidth();
        int sample = 1;
        while (want > 0 && THUMB_SRC_W / (sample * 2) >= want) sample *= 2;
        o.inSampleSize = sample;
        Bitmap[] out = new Bitmap[items.size()];
        for (int i = 0; i < out.length; i++) {
            Feed.Item it = items.get(i);
            Bitmap b = thumbCache.get(it.id);
            if (b == null) {
                File f = thumbFile(it);
                if (!f.exists()) continue;
                b = BitmapFactory.decodeFile(f.getPath(), o);
                if (b == null) {            // damaged download: fetch it again next time
                    f.delete();
                    continue;
                }
                thumbCache.put(it.id, b);
            }
            out[i] = b;
        }
        return out;
    }

    // Cache cleaner. Keeps this app's cache folder (what Android lists as "Cache" under App info) under
    // CacheCleaner.CAP_BYTES, 3 MB: leftovers of interrupted downloads and installed updates go first,
    // then the oldest thumbnails - never those of the videos on the shelves. Runs after thumbnails were
    // downloaded and with every memory sweep; never on the UI thread. Touches nothing but our own cache.
    private void cleanCache() {
        try {
            if (updater != null) updater.tidy();
            CacheCleaner.trim(getCacheDir(), pinned, CacheCleaner.CAP_BYTES, System.currentTimeMillis());
        } catch (Throwable ignored) { }
    }

    // keeps every thumbnail whose video is still in the feed cache, so a recommendation that rotates
    // out and back in a few refreshes later does not have to be downloaded again (cleanCache has the last word)
    private void pruneThumbs(List<Feed.Item> all) {
        HashSet<String> keep = new HashSet<>();
        for (Feed.Item it : all) keep.add(it.id + ".jpg");
        File[] files = thumbDir.listFiles();
        if (files == null) return;
        for (File f : files) if (!keep.contains(f.getName())) f.delete();
    }

    // UI thread
    private void apply(Snapshot s) {
        busy = false;
        if (s != null && !destroyed) {
            hasData = !s.w.isEmpty() || !s.m.isEmpty();
            lastFetched = s.fetched;
            String status = status(s);
            wrestling.setNote(status);
            movies.setNote(s.m.isEmpty() ? status : "recommended · " + status);
            // A shelf the user is browsing right now is not touched: cards never change under the
            // focus ring. It catches up on the next pass (the next timer tick, or when the home screen returns).
            // Right after coming back from another app nobody is browsing (fromApp), so the shelf the
            // video was opened from is refreshed like the others once the clock has run out.
            if (!s.wSig.equals(shownW)) {
                if (s.wb == null) {
                    again = true;   // the shelf was cleared meanwhile: go round once more, decoding this time
                } else if (fromApp || !wrestling.hasFocus()) {
                    shownW = s.wSig;
                    wrestling.show(s.w, s.wb, s.wMeta, openVideo);
                }
            }
            if (!s.mSig.equals(shownM)) {
                if (s.mb == null) {
                    again = true;
                } else if (fromApp || !movies.hasFocus()) {
                    shownM = s.mSig;
                    movies.show(s.m, s.mb, s.mMeta, openVideo);
                }
            }
        }
        if (again && !destroyed) {
            again = false;
            requestWork();
        }
        scheduleTick();                  // the next refresh is due 10 minutes after the last download
    }

    private String status(Snapshot s) {
        if (s.w.isEmpty() && s.m.isEmpty()) {
            return s.online ? "could not load yet" : "connect to Wi-Fi to load";
        }
        String t = "updated " + Feed.age(s.fetched, s.now) + " ago";
        return s.online ? t : t + " · offline";
    }

    private void playOnYoutube(String id) {
        Uri u = Uri.parse("https://www.youtube.com/watch?v=" + id);
        for (String pkg : YOUTUBE_APPS) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u).setPackage(pkg)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                noteLaunched(pkg);
                return;
            } catch (Exception ignored) { }
        }
        try {   // no known YouTube app: let the system pick (a browser works too)
            startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Toast.makeText(this, "No YouTube app found on this TV", Toast.LENGTH_LONG).show();
        }
    }

    private void load() {
        final int my = ++gen;
        new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            PackageManager pm = getPackageManager();
            List<App> out = new ArrayList<>();
            HashSet<String> seen = new HashSet<>();
            String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
            for (String c : cats) {
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(c);
                for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                    ActivityInfo ai = ri.activityInfo;
                    if (ai.packageName.equals(getPackageName()) || !seen.add(ai.packageName)) continue;
                    App a = new App();
                    a.ri = ri;
                    a.pkg = ai.packageName;
                    a.label = String.valueOf(ri.loadLabel(pm));
                    a.intent = new Intent(Intent.ACTION_MAIN).addCategory(c)
                            .setClassName(ai.packageName, ai.name)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                    out.add(a);
                }
            }
            Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
            ui.post(() -> {
                if (my != gen) return; // a newer reload is already on its way
                apps = out;
                adapter.notifyDataSetChanged();
                if (grid.getSelectedItemPosition() < 0 && !out.isEmpty()) grid.setSelection(0);
            });
        }).start();
    }

    // draw the banner/icon once into a bitmap that is exactly the tile image size
    private BitmapDrawable shrink(Drawable d, boolean banner) {
        int h = dp(83);
        int w = banner ? dp(148) : h;
        Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        d.setBounds(0, 0, w, h);
        d.draw(new Canvas(bm));
        return new BitmapDrawable(getResources(), bm);
    }

    private void fetch(final App a, final ImageView iv) {
        if (a.ri == null) return;
        try {
            io.execute(() -> {
                // the tile was scrolled away (or reused for another app) before we got to it:
                // skip the work, it is requested again if the tile comes back into view
                if (!a.pkg.equals(iv.getTag())) return;
                BitmapDrawable out = cache.get(a.pkg);   // a duplicate request may have decoded it already
                if (out == null) {
                    PackageManager pm = getPackageManager();
                    try {
                        Drawable d = a.ri.activityInfo.loadBanner(pm);
                        if (d == null) d = a.ri.activityInfo.applicationInfo.loadBanner(pm);
                        boolean banner = d != null;
                        if (d == null) d = a.ri.loadIcon(pm);
                        if (d != null) out = shrink(d, banner);
                    } catch (Throwable ignored) { }
                    if (out == null) return;
                    cache.put(a.pkg, out);
                }
                final BitmapDrawable fd = out;
                ui.post(() -> { if (a.pkg.equals(iv.getTag())) iv.setImageDrawable(fd); });
            });
        } catch (Exception ignored) { }
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return apps.size(); }
        @Override public Object getItem(int i) { return apps.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            Tile t;
            if (v == null) {
                LinearLayout r = new LinearLayout(MainActivity.this);
                r.setOrientation(LinearLayout.VERTICAL);
                r.setGravity(Gravity.CENTER_HORIZONTAL);
                r.setPadding(dp(6), dp(6), dp(6), dp(6));
                r.setLayoutParams(new AbsListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(118)));

                t = new Tile();
                t.img = new ImageView(MainActivity.this);
                t.img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                t.img.setBackgroundColor(0x22FFFFFF);
                r.addView(t.img, new LinearLayout.LayoutParams(dp(148), dp(83)));

                t.txt = new TextView(MainActivity.this);
                t.txt.setTextColor(0xFFFFFFFF);
                t.txt.setTextSize(13);
                t.txt.setSingleLine(true);
                t.txt.setEllipsize(TextUtils.TruncateAt.END);
                t.txt.setGravity(Gravity.CENTER);
                t.txt.setShadowLayer(3, 0, 1, 0xFF000000);
                LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                        dp(148), ViewGroup.LayoutParams.WRAP_CONTENT);
                tp.topMargin = dp(4);
                r.addView(t.txt, tp);

                r.setTag(t);
                v = r;
            } else {
                t = (Tile) v.getTag();
            }
            App a = apps.get(i);
            t.txt.setText(a.label);
            t.img.setTag(a.pkg);
            Drawable d = cache.get(a.pkg);
            if (d != null) {
                t.img.setImageDrawable(d);
            } else {
                t.img.setImageDrawable(null);
                fetch(a, t.img);
            }
            return v;
        }
    }
}
