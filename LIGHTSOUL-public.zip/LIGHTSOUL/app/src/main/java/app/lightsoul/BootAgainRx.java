package app.lightsoul;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * The second, delayed attempt of BootRx. It is a separate receiver that is NOT exported, so only
 * the alarm BootRx sets can reach it (BootRx itself has to be exported for the system's boot
 * broadcast, and an exported receiver can be poked by any other app).
 */
public final class BootAgainRx extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (BootRx.mayTakeOver(c)) BootRx.goHome(c);
    }
}
